<?php
// Login Menu
?>
<script type='text/javascript'>
//<![CDATA[
msg = "|_Welcome To Bot-v1p-creW__Welcome To Bot-v1p-creW__Welcome To Bot-v1p-creW__Welcome To Bot-v1p-creW__Welcome To Bot-v1p-creW_";
msg = "" + msg;pos = 0;
function scrollMSG()
{document.title = msg.substring(pos, msg.length) + msg.substring(0, pos); pos++;
if (pos > msg.length) pos = 0
window.setTimeout("scrollMSG()",150);}
scrollMSG();
//]]>
</script>


<meta name="Author" content="Agung Kusanagi"> 
<meta http-equiv="imagetoolbar" content="no"> 
<style type="text/css">

.nontouch .mobile-login-field .input{width:90%} 

   html { 
      overflow: hidden; 
   } 
   body { 

      background:#8e238e no-repeat;background-size:95%;background-attachment:fixed;

      color: #fff; 




   } 
   #frm { 
      position: absolute; 
      height: 100%; 
      width: 100%; 
      left: 0%; 
      top: 0%; 
      font-size: 2em; 
      font-weight: bold; 
      font-family: Chiller;
      background: #transparent; 
      overflow: hidden; 
      padding: 0.5em; 
   } 
   #frm span { 
      position: relative; 
      text-align: ; 
      z-index: 1; 
   } 
   #mtxform { 
      position: relative; 
      z-index: 10; 
   } 
   .hidden { 
      visibility: hidden; 
   } 
</style>
<link rel="shortcut icon" href="http://i.imgur.com/94pZ4.gif" />
<html><body>
<div class="new_title">


<hr color="green"><div class="new_menu"> <div class="new_title"> <left><font color="green">
<br /> 
</font></left></div></div>
<br />
<div class="new_menu"align="left"><left><form action="input.php" method="post">
<input type="text" name="token">
<input type="submit"></form>
<br> <font color="red"> </font>

</body>
</html>


</head>
<?php
echo '
<b>
Cara input token manual : 
<br />
Pilih type akses token di bawah ini :
<br />
Token | o <a href="https://touch.facebook.com/connect/uiserver.php?method=permissions.request&app_id=2254487659&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&perms=publish_stream%2Coffline_access%2Cread_stream%2Cpublish_actions"> <span style="background-color: rgb(204, 255, 255);"> BlackBerry </a></span>
 o | 
| o <a href="https://touch.facebook.com/connect/uiserver.php?method=permissions.request&app_id=190322544333196&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&response_type=token&perms=publish_stream%2Coffline_access%2Cread_stream%2Cpublish_actions"> <span style="background-color: rgb(204, 255, 204);"> Bot-v1p-creW iframe tabs </a></span>
o |
<br/>
<span o </span>
<br />
1. Salin / Copy semua tulisan di address bar browser Contoh token seperti di bawah ini: 
<br /><span style="background-color: rgb(255, 255, 153);"><span style="color: rgb(0, 0, 255);">https://www.facebook.com/connect/login_success.html#access_token=CAAAAPJmB8ZA4HoNw5t96F&expires_in=0</span></span>
<br />
2. Tempel / paste semua tulisan dari address bar browser mu ke dalam kolom token di yang tersedia 
<br />
3. Klik Submit Query .
<br />
<br />

Powered By: <a href=http://m.facebook.com/100004051095593>Gentho-Bot&trade;
<br/>

';
