<?php
//Bot-v1p-creW Cron by. Agung Kusanagi
include 'dataLog.php';
$url = $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);

if($dataLog [bot_type] == 'like_only'){ auto('http://'.$url.'/like_only.php'); }
if($dataLog [bot_type] == 'like_simple_only'){ auto('http://'.$url.'/comment_simple.php'); }
if($dataLog [bot_type] == 'comment_like_emoji'){ auto('http://'.$url.'/comment_motivasi.php'); }
if($dataLog [bot_type] == 'full_zi_bot'){ auto('http://'.$url.'/comment_motivasi.php'); }
if($dataLog [bot_type] == 'full_zi_bot'){ auto('http://'.$url.'/respon_comment.php'); }
if($dataLog [bot_type] == 'full_zi_bot'){ auto('http://'.$url.'/respon_like.php'); }
if($dataLog [bot_type] == 'full_zi_bot'){ auto('http://'.$url.'/respon_status.php'); }
auto('http://'.$url.'/refresh.php');


//Bot-v1p-creW Cron by. Zherman Ilyas
function auto($url){
$cx=curl_init();
curl_setopt($cx,CURLOPT_URL,$url);
curl_setopt($cx,CURLOPT_RETURNTRANSFER,1);
$ch=curl_exec($cx);
curl_close($cx);
return($ch);
}
?>
