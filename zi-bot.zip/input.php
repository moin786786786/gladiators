<html><body>
<font color="red">Token telah tersimpan ! - bot akan segera aktive, Jika bot mu mati silahkan masukan token lagi di menu ini ... </font>
<br/>


<?php
$newtoken = $_REQUEST['token'];
if ($newtoken==true){

$cut = explode('token=',$newtoken);
$cuts = explode('&expires',$cut[1]);
$newtoken = $cuts[0];

$file = fopen("my_token.txt","w");
fwrite($file,$newtoken);
fclose($file);



}
?>
</body>
</html>