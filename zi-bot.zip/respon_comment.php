﻿<?php
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met dini 🌙 hari . ','Met jelang pagi . ','Selamat 🌷 Pagi 🌷 ','Met 🌷 Pagi 🌱 ','｡◕‿◕｡ ','☀~ ','Breakfast time 🍔☕🍸🍺 . ','Met Tifitas 💻 ','Have a nice day ☀ . ','Good ☀ Day . ','Time for 🍔☕🍸🍺 lunch . ','Met makan 🍔☕🍸🍺 siang ☀ .','Good siang ☀ . ','Met jelang sore . ','Good afternoon . ','☀~ ','Salam kompak 👈jempoler👉 ','Good evening . ','Time for 🍔☕🍸🍺 dinner . ','Met 📺 Online ~ . ','Met 💤 rehat .','Have 💤 nice 💤 dream . ','Good 🌙 night 🌙 ','Good merem 💤💤 ','Met rehat 💤💤 ',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);

$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.facebook.com/me/home?fields=id&access_token='.$access_token.'&offset=1&limit=5'),true);


$log = json_encode(file('Restart_logz1'));
for($i=1;$i<=count($stat[data]);$i++){
$com = json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=25&fields=id,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
$dat = explode($com[data][$c-1][id],$log);
if(count($dat) > 1){
echo'Done<br/>';
}else{
$logx = $com[data][$c-1][id].'__';
$logy = fopen('Restart_logz1','a');
fwrite($logy,$logx);
fclose($logy);
$qwerty = array('0','1','2','3','4','5','6','7','8','9','10',);
$emo = array(' 🌱 ',' 🌸 ',' 🌷 ',' 🍀 ',' 🌹 ',' 🌻 ',' 🌺 ',' 🍃 ',' 🌾 ',' 💐 ',);

$inc=array('emojitor.php',);
include $inc[rand(0,count($inc)-1)];
$mess = $text[rand(0,count($text)-1)];
$emojitor = str_replace($qwerty,$emo,$mess);		

$gen = json_decode(auto('http://graph.facebook.com/'.$com[data][$c-1][from][id].'?fields=gender'),true);

if($gen[gender] == 'male'){
$arr_gen = array('👮 Mas ','👮 Mas ',);
$gender = $arr_gen[rand(1,5)];
}else{
$arr_gen = array('<3 ','<3 ','<3 ',);
$gender = $arr_gen[rand(0,2)]; }
$exp_nam = explode(' ',$com[data][$c-1][from][name]);
$nama=$gender.' '.$exp_nam[0];
$tags = explode(' ',$com[data][$c-1][from][id]);
$tagged_name = ' @['.$tags[0].':1] ';


$arr_mess = array(

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
.. jangan fb-an truz '.$nama.' ntar pulsa na jebol😹 😹WkWKWkWk ...   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Apa kabar '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Lagi apa nih '.$nama.' ? :D ......  ', 
'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
muter-muter beranda malah ketemu   '.$nama.' di sini  :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Hehehe :D ......  ', 
'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Lagi apa nih :D   '.$nama.' ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
dari mana aja '.$nama.' baru nongol :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Minum teh dulu 🍸  '.$nama.' ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
robot jalan komen manual juga hadir '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Mendingan banyak 👦👧 temen dari pada banyak musuh 
setuju gak   '.$nama.' ? ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
3 tahapan orang berilmu : tahap terendah adalah ketika dia mengetahui sedikit tapi menyombongkan ke seluruh dunia, tahap menengah adalah ketika dia mengetahui lebih banyak tapi dia lebih banyak diam dan merendah, tahap tertinggi adalah ketika dia mengetahui banyak hal dan merasa bahwa dia belum mengetahui apa-apa.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
lima menit setelah terbangun, Anda akan melupakan 50% dari mimpi Anda.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jangan takut dengan masalah, karena itu akan membuat kita  semakin dewasa.. Dan jangan mencari-cari masalah, karena itu pertanda kita  belum cukup dewasa..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jangan terlalu sering membanding-bandingkan dirimu dengan orang lain, karena dirimu cuma ada satu di dunia ini..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jangan terus tangisi dia yg telah meninggalkanmu. Suatu saat seseorang akan berterima-kasih padanya karena telah melepaskanmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jangan terus tangisi dia yg telah pergi. Tersenyumlah karena dia telah berimu kesempatan tuk bertemu seseorang yg lebih baik.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jgn hitung brp kali org menyakiti & meninggalkanmu, tp brp kali kau menyakiti Tuhan & Ia tdk prnh meninggalkanmu    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jgn sia-siakan air matamu utk org yg meninggalkanmu. Bkn kau yg kehilangan mrk, tp mrk yg telah kehilangan dirimu  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika Anda bisa membuat orang lain tertawa, maka Anda akan mendapatkan semua cinta yang Anda inginkan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika dia yg kita  cinta melukaimu, beritahu dia. Tapi jika dia terus melakukannya, lepaskan dia   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  ingin hidup kita  bahagia, mulailah dengan menyingkirkan segala hal yg membuat kita  tidak bahagia.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  ingin mendapat perhatian, mulailah dengan berhenti memintanya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  mempunyai masa lalu yang indah, bersyukurlah.. Karena kita  pernah merasakan keindahan itu.. Jika kita  mempunyai masa lalu yang buruk, bersyukurlah.. Karena masa lalu yang buruk itu telah menjadi masa lalu...   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  percaya mampu meraih impianmu, maka teruslah berusaha. Keberhasilan itu akan memberimu kebahagiaan tak ternilai.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  tak bisa menjadi PENSIL tuk menulis kebahagiaan seseorang, jadilah PENGHAPUS tuk menghilangkan kesedihannya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita  tidak pintar, jadilah kreatif.. Jika kita  tidak kreatif, berfikiranlah positif.. Jika kita  sudah berfikiran positif, maka kita  akan kreatif dan mengalahkan orang-orang pintar..   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita belum merasa bahagia, maka mungkin karena kita belum bersyukur dari apa yang telah kita miliki   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika kita mencintai seseorang, berusahalah cintai kekurangannya, bukan hanya mengubahnya seperti yang kita mau.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika km melihat ada sesuatu yg salah, mungkin kesalahannya bukan apa yg km lihat, tapi bagaimana caramu melihat.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika seseorang membencimu tanpa sebab yang pasti, maka mungkin itu adalah hobinya, atau keahliannya.  👈😜👉__   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika seseorang tulus mencintaimu, tak ada yg mampu buatnya jauh darimu. Jika tidak, tak ada yg mampu buatnya tetap bersamamu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika sudah berusaha, ikhlaskan kepada Tuhan yg maha kuasa. Karena semuanya akan kembali kepada Nya.',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jika yg telah diperoleh saat ini berbeda dari yg diharapkan, tetaplah bersyukur, dan yakini bahwa itu yg terbaik untuk saat ini.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Jodoh itu ada di Tangan Tuhan.. dan tugas kita hanyalah berusaha mengambilnya, bila kita tidak ingin jodoh kita ada di tangan Tuhan terus, maka berusahalah untuk mengambilnya, lalu jagalah, rawatlah, atau Tuhan akan mengambilnya lagi dari tangan kita..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang kita  harus berhenti peduli pada seseorang, bukan karena kita  membencinya, tapi karena dia tak pernah menyadari kepedulianmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang kita  harus melepaskan, bukan karena tak cinta, tapi karena kita  lebih mencintai dirimu yg terus terluka.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang meski tahu bahwa terlalu berharap bisa buatmu sangat terluka, kita  tetap tak mau berhenti berharap sebelum dapat jawabannya  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang meski terus terluka, kita  tetap tak ingin melepasnya. Meski terdengar bodoh, tapi kita  masih berharap dia akan berubah  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang tak peduli betapa besar kita  mencintai seseorang, kita  terpaksa melepasnya, karena hatimu lelah tuk terus terluka.   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang, ketika sedih, kita  menyendiri. Karena kita  tahu satu-satunya orang yg mampu buatmu tersenyum kembali adalah dirimu sendiri  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kadang, masalah adalah satu-satunya cara tuk tahu siapa yg tulus peduli padamu dan siapa yg berpura-pura jadi temanmu  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kalau gak bisa percaya sama orang lain, percaya diri aja.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kalaulah kita  tidak mampu untuk menggembirakan orang lain, janganlah pula kita  menambah dukanya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kasih sayang tak hanya ditunjukkan oleh sanjungan dan pujian, tetapi juga teguran atas kesalahan dan kelalaian  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kata-kata itu tenaga yang luar biasa. Seandainya mulut HItler diplester, Perang Dunia ke 2 tak akan ada.   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kau selalu bs mempercayai tanpa hrs mencintai, tp kau tdk akan prnh bs mencintai tanpa mempercayai.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kau takkan pernah tahu kesuksesan itu jikalau tak pernah mencoba dan hanya menyerah   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kawan sejati ialah orang yg mencintaimu meskipun telah mengenalmu dengan sebenar-benarnya ia itu baik dan burukmu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kebahagiaan datang dari rasa syukur. Rasa syukur datang dari hal yang telah kita miliki, bukan dari yang belum kita miliki.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kebahagiaan mulai tercipta ketika kita berhenti dikuasai keinginan, dan mulai menguasai keinginan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kebahagian tidak diukur dari seberapa banyak yang dimiliki, tetapi dari perasaan mensyukuri apa yang dimiliki.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kebanyakan orang gagal adalah orang yang tidak menyadari betapa dekatnya mereka ke titik sukses saat mereka memutuskan untuk menyerah   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kebanyakan orang tak mau melepaskan apa yg sudah pergi. Itulah yg membuat masalah menjadi berat.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Keikhlasan bukan berarti kita menyerah. Karena keikhlasan adalah bahan bakar yang baik untuk perjuangan selanjutnya.   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Keikhlasan hati dan ketegasan sikap, akan menjadikan kita  lebih siap dan lebih berani dalam menyelesaikan setiap masalah.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kejujuran adalah batu penjuru dari segala kesuksesan, Pengakuan adalah motivasi terkuat.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kejujuran yg menjadi kebiasaan membawa kebanggaan. Kebohongan yg menjadi kebiasaan membawa kesengsaraan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kekalahan hanya akan jadi berharga jika kita mampu menjadikannya sebagai pelajaran untuk pertandingan selanjutnya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kekecewaan adalah cara Tuhan tuk mengatakan. Bersabarlah, Aku punya sesuatu yg lebih baik untukmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kekecewaan mengajar kita arti kehidupan. Teruskan perjuangan kita walau terpaksa utk hadapi rintangan demi rintangan hidup   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 KEKUATIRAN tidak pernah memperbaiki hari esok, bahkan hanya melemahkan SUKACITA pada hari ini   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kekurangan & kelebihan adalah bagian dari kesempurnaan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kenali dirimu sendiri dulu sebelum kita  mulai berbicara buruk tentang orang lain. Sudah pantas kah kita  menilai orang lain?   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kenyataan tak selalu indah, tapi selalu ada keindahan dibalik setiap kenyataan..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesakitan pasti berlalu. Dan ketika sakit itu hilang, kita  akan merasa lebih kuat, lebih bahagia, dan lebih waspada.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesalahan adalah guru terbaik manusia ketika ia cukup jujur untuk mengakuinya dan bersedia untuk belajar dari mereka.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesalahan adalah pengalaman hidup, belajarlah darinya. Jangan mencoba tuk menjadi sempurna. Cobalah menjadi teladan bagi sesama.   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesalahan besar harus diimbangi dengan interospeksi diri yang sangat dalam.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesempatan tidak datang dua kali . Just do it  Jangan sampai menyesal karena kesempatan tersebut berlalu begitu saja   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 kesuksesan itu penuh tantangan,gagal sekali dua kali itu biasa,tetaplah konsisten dengan mimpi kita   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kesulitan sebesar apapun akan terasa wajar bagi jiwa yang tetap melebihkan syukur daripada mengeluh..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketahuilah, hal-hal terindah di dunia ini terkadang tak bisa terlihat dalam pandangan atau teraba dengan sentuhan, mereka hanya bisa terasakan dengan hati.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketakutan-ketakutan akan membatasi Anda untuk melakukan berbagai hal yang sangat berarti bagi Anda   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika dia yg pergi memberimu 100 alasan tuk menangis, tunjukkan padanya bahwa kita  punya 1000 alasan tuk tersenyum.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika ditanyakan mengenai IQnya pada tahun 2004, Stephen Hawking menjawab, Saya tidak tahu. Orang yang membanggakan IQnya adalah seorang pecundang.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika hati sedang gundah, gelisah dan dipenuhi dengan keputusasaan, ingatlah bahwa hanya kepada Tuhan kita mengadu  ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika keadaan mengharuskan untuk menangis, tak usah berpura, menangislah. Tak semua air mata berarti lemah.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika kekuatan akan cinta melebihi kecintaan akan kekuasaan, maka dunia pun menemukan kedamaian.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika kita  benar, tak seorangpun mengingat. Ketika kita  salah, tak seorangpun lupa    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika kita  mencintai seseorang, berikan dia pilihan tuk meninggalkanmu, tapi jangan pernah memberikannya alasan tuk pergi.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika kita  telah mencoba segalanya, kita  telah lakukan semampumu, tapi tak juga bisa, serahkanlah pada Tuhan. PRAY   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika kita berencana maka biarkanlah Tuhan yg menjadi penghapusnya dan menggantinya dengan yg lebih baik.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika km berharap yg terbaik tp km hanya mendapat yg biasa, bersyukurlah km bukan yg terburuk.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika Tuhan memberimu masalah, Dia tahu bahwa kita  pasti bisa melaluinya. Mungkin akan ada luka, tapi itu semua buatmu dewasa.    ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika Tuhan tak menjawab doamu, itu karena Dia tahu bahwa yg kita  inginkan akan berakibat buruk tuk hidupmu nantinya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketika tulus mencinta, kita  tak akan menyerah. kita  mungkin lelah, tapi kita  tetap berusaha, karena cinta selalu temukan cara.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketka kita sedang tdk mengingat-Nya bahkan Ia selalu bsama kita dan menurunkan semua anugerah-Nya. Lalu pantaskah kita merusak semuanya?.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ketulusan cinta dan kasih sayang tidak dapat dilihat atau didengar, tetapi hanya bisa dirasakan dengan hati.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 kita  tak akan bisa hanya sekedar teman biasa dengan dia yg PERNAH kita  cinta, karena sebagian dirimu akan selalu mencintainya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 kita  tak akan dapatkan apa yang kita  inginkan, jika kita  terlalu sibuk mengeluh apa yang kita  miliki saat ini tak cukup bagimu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kita akan belajar lebih banyak mengenai sebuah jalan dengan menempuhnya, daripada dengan mempelajari semua peta yag ada di dunia   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kita memang tidak selalu mendapatkan apa yg kita inginkan, namun percayalah, Tuhan memberikan apa yg kita butuhkan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kita tidak dapat meneruskan hidup dengan baik jika tidak dapat melupakan kegagalan dan sakit hati di masa lalu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Km akan lelah sendiri jika km terus mengikuti kata orang lain. Bagaimana pun, yg mereka katakan tidak slalu benar.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Km tak bisa mengubah sgala sesuatu dalam satu malam, tapi km dapat mengubahnya sedikit demi sedikit  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Kualitas dari kehidupan se2orang itu tergantung pada komitmennya utk berhasil, bidang apapun yg dia tempuh   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Lahir yang sehat terasa sempurna saat diimbangi dengan batin yang kuat, lalu kita bersyukur.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Laksanakan perintah, menjauhi larangan, berserah dgn ikhlas. Maka Tuhan akan menjaga, memelihara dan melindungi.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 lakukan apa yang dapat kita  lakukan, dengan apa yang kita  miliki dan di tempat kita  berada   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Lakukanlah apa yang kita  ingin lakukan. selama itu bernilai positif bagi kita .   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 lakukanlah yang terbaik dan kita  akan dapat hasil yang terbaik pula   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Lelah karena bekerja jauh lebih nikmat daripada lelah karena tidak ada kerjaan.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Lewat imajinasi, anak-anak bisa menemukan kesenangan dari hal-hal kecil yang mereka temukan. Bertambah usia, semakin membatasi imajinasi, semakin sulit menemukan kesenangan, bahkan dari hal-hal besar yang kita dapatkan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Lupakan kekecewaan, karena harapan dimasa depan masih terbentang luas dan begitu cerah   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mahkotai hati dengan keikhlasan. Karena hal itu akan menjadikan kita tetap bertahan dalam menghadapi rumitnya kehidupan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mampu tertawa ketika segala sesuatu dalam dirimu terluka, adalah salah satu bukti seberapa kuat kita  dalam menjalani hidup ini.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Manusia biasanya lebih menghargai sesuatu yg sukar diperoleh tapi sering melupakan nikmat yg telah tersedia   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Masa lalu adalah pembelajaran tuk lebih dewasa dalam menyikapi masalah yg mungkin sama dengan yg kita alami dimasa lalu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Masalah adalah ujian pendewasaan. Jadi tidak ada alasan menyalahkan orang lain. Benahi diri sendiri dan jadi pribadi yg dewasa  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Masalah orang miskin ketika dompet mulai menipis , Masalah orang kaya   ketika handphone mulai low batt ?? bener gak sih ??   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Melepaskan dia yg kita  cinta adalah hal yg sulit, tapi jauh lebih sulit tuk tetap bertahan jika dia tak merasakan hal yg sama.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Memaafkan memang takan mengubah MASA LALU, tapi pasti akan mempermudah MASA DEPAN   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Memiliki IMPIAN saja belum cukup. Miliki komitmen untuk MERASA HARUS dan BERTEKAD mencapai impian tersebut   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mempertahankan mungkin lebih sulit daripada mendapatkan, tetapi tak akan ada yang sulit jika telah ada niat  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Menatap masa depan bukan berarti harus melupakan masa lalu. Mengingat masa lalu bukan untuk disesali, tapi sebagai pelajaran untuk menghargai hari ini.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mencemaskan apa yg mungkin terjadi hanya membuang waktumu. Itu hanya membebani pikiranmu dan mengambil kebahagiaanmu  ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 MENCINTAI bukan bagaimana kita  MELIHAT tp bagaimana MERASAKAN. Bukan bagaimana kita  MENDENGAR tp bagaimana MENGERTI.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mencintai seseorang berarti menjadikannya bagian dari dirimu. Itu sebabnya akan terasa sakit saat kehilangannya.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mengeluh tak akan pernah menyelesaikan apapun, tapi hanya akan menambah beban. Berhentilah mengeluh, segera ambil tindakan  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Menghormati org yg lbh tinggi darimu, itu biasa. Menghormati org yg lbh rendah darimu, itu luar biasa.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mengucapkan kta2 negatif sprti halnya sseorang menancapkan paku2 di sebatang pohon.Walaupun paku sdh tercabut,tetap aj meninggalkan bekas.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Meninggikan derajat orang lain tidak akan membuatmu menjadi rendah, sama halnya dengan merendahkan orang lain tidak akan meninggikanmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Menjaga kata-katamu tidak semudah mengucapkannya. Membuktikannya? Itu cerita lain.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Menuliskan tujuan akan sangat membantu dalam menjaga alasan melakukan sesuatu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mereka tak peduli dari mana kita  memulainya. Mereka melihat dari bagaimana caramu mengakhirinya.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mereka tidak pernah berpikir melalui pikiranku, tidak mendengar melalui telingaku, tidak melihat melalui mataku. Jadi, mereka tidak bisa memaksa saya untuk menyukai apa yang mereka suka, atau membenci apa yang mereka benci.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mereka yg mencintaimu slalu ingin yg terbaik untukmu, hanya saja cara mereka bukan slalu yg terbaik  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Meskipun melakukan kesalahan dalam tindakan, namun jika didasari dgn niat baik, pasti Tuhan akan menunjukkan jalan yg terbaik.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mgkn saja setiap masalah & tantangan yg kita anggap sulit itu masih ada solusinya, namun blom terpikirkan oleh kita   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Miliki hati yg tak pernah membenci, senyuman yg tak pernah menyakiti dan kasih sayang yg tak pernah berakhir.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Miliki iman utk mengucap selamat tinggal, karena di saat itu Tuhan akan memberikan selamat datang yg lebih pantas bagi kita.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mimpi mmg sangat perlu utk memelihara gairah hidup & kemajuan, tapi mimpi tanpa disertai tindakan hanyalah seperti pepesan kosong belaka   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mimpi tidak hanya membantu Anda berhadapan dengan kegagalan, tetapi mereka juga memotivasi Anda secara konstan   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mimpikan yang kau mau dan kejarlah impianmu itu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Minuman yang dingin dapat memperlambat proses pencernaan dan bisa mengakibatkan mengkerutnya saluran-saluran darah.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Musik berfungsi sebagai stimulus pembangkit ingatan ke masa lalu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Mustahil itu OPINI. Ketika Anda TIDAK YAKIN dapat mencapai IMPIAN, sesungguhnya Anda sudah GAGAL SEBELUM MEMULAI   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Never tell God that u have a big PROBLEM, but tell ur problem that u have a BIG GOD   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 orang bijak adalah orang yang selalu belajar dari kegagalannya sedangkan orang yang bodoh adalah orang yang selalu menutupi kegagalannya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Orang hadir di hidupmu karena sebuah alasan. Mereka berimu bahagia dan kecewa. Ada yg sesaat, tapi ada yg selamanya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Orang slalu bilang km perlu melakukan ini dan itu, tp km tahu yg terbaik ttg dirimu dan apa yg perlu km lakukan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Orang sukses takkan pernah mengeluh bagaimana kalau akan gagal,namun berusaha bagaimana untuk berhasil   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 orang yang gagah perkasa itu bukan orang yang bertubuh kekar melainkan orang yang mampu mengendalikan emosinya ketika marah   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Orang yg berjaya dalam hidup adalah orang yg nampak tujuannya dengan jelas & menjurus kepadanya tanpa menyimpang   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Orang2 berhasil tidak hanya keras hati, mereka juga pekerja keras yg percaya pada kemampuan dirinya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Org bs berkata apapun tentang kita . Tp siapa dirimu sebenarnya, hny kita  yg tahu, & hny kita  yg menentukan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Pasangan yang tepat akan datang di waktu yang tepat, bukan dipercepat.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Pemimpin zalim, ketika ada masalah, mencari siapa yang salah. Pemimpin sejati, ketika ada masalah, mulai mencari siapa yang bisa membenarkan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Pengetahuan ditingkatkan dgn belajar, kepercayaan dgn perdebatan, keahlian dgn latihan & cinta dgn kasih sayang   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Perbedaan antara mereka yang berhasil dengan yang tidak bukan hanya dari ilmunya, tetapi dari kesungguhan dan keinginannnya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Percayalah, hari ini akan lebih indah daripada kemarin jika kita mengawalinya dengan doa dan senyuman.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Perempuan diambil dari tulang rusuk laki-laki. Bukan dari kepala untuk jadi atasan, juga bukan dari kaki untuk jadi bawahan. Tapi dari tulang rusuk, yang melindungi jantung laki-laki.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Pria sering kehilangan wanita yg dicintainya, karena mereka tak pernah mau belajar menghargai perasaan wanitanya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Proyek besar tak bisa diselesaikan sekaligus, tapi hrs di bagi2 kebagian yg kecil & dapat dikendalikan   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Rasa sakit membuatmu lebih kuat. Rasa takut membuatmu lebih berani. Patah hati membuatmu lebih bijaksana. Ambil hikmahnya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat aku berhenti berdoa utk keinginanku adl saat aku menyadari bhw keinginan Tuhan jauh lbh besar dr doa-doaku.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat dirimu merasa lelah dalam mengejar mimpimu, tetap bayangkan kembali rasa menggebu-gebu yang pernah ada dalam hatimu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat kau membalas kebencian dgn amarah & caci maki, saat itulah musuhmu menang.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat kita  mencoba meniru gaya orang lain dan gagal, coba ciptakan sendiri gayamu. Mungkin orang lain yang akan mencoba meniru gayamu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat kita terlambat mengetahui apa yang harus kita lakukan itulah penyesalan. Saat kita telah mengetahui apa yang harus kita lakukan itulah kesadaran   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat suatu hubungan berakhir, bkn berarti 2 org berhenti saling mencintai. Mereka hny berhenti saling menyakiti.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saat tekanan melanda, jangan merasa tertekan. Jadilah seperti bola di atas air. Ditekan seperti apapun, kita  tetap akan bisa ke atas lagi. Semakin kuat tekanannya semakin kuat tekat naik ke atas.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sahabat adalah mereka yg tahu kapan saat yg tepat tuk menyemangati, membiarkanmu sendiri, dan saat tuk berbagi.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sahabat adalah mereka yg tetap ingin menemani harimu, tak peduli apa yg dikatakan orang lain tentangmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sahabat slalu ada untukmu, ketika kita  punya masalah. Bahkan terkadang memberi saran yg bodoh hanya tuk lihat kita  tertawa.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sahabat tak akan menghilang saat masalah datang, tapi menggandeng tanganmu dan menghadapinya bersama-sama.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sahabat, adalah mereka yang tetap ada, walau seluruh dunia berkata kau tak lagi berharga.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Salah satu alasan kenapa sebuah hubungan berakhir adalah karena berhenti melakukan hal yg dilakukan ketika pertama kali bertemu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Salah satu alasan mengapa donat berlubang di tengah adalah agar permukaan donat yang terkena minyak bertambah dan donat cepat matang.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Salah satu hal paling bahagia di dunia ini adalah melihat ibumu tersenyum, dan lebih bahagia lagi ketika tahu kita lah alasannya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Salah satu hal tersulit dalam hidup ini adalah berhenti mencintai seseorang hanya karena dia telah berhenti mencintaimu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Salah satu langkah efektif untuk menyelesaikan masalah adalah dengan mengubah sudut pandang.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Saudaraku, mungkin sesuatu yang membuat kita bersedih dan menangis hari ini adalah sesuatu yang justru akan membuat kita tersenyum esok hari. Tetapi, kita harus tetap bertahan untuk menyambut saat paling membahagiakan itu datang kelak.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Secara umum, orang banyak akan mengatakan nobody s perfect.. Bagi orang yang sedang jatuh cinta, ia akan mengatakan somebody s perfect..Tapi seorang yang cerdas akan mengatakan everybody s perfect, karena dibalik kekurangan, ia bisa menemukan kesempurnaan..   :)   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sederhanakanlah sesuatu yang kita  anggap rumit, tapi jangan pernah diremehkan..    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Segala sesuatu lebih mudah diucapkan daripada dilakukan. Tapi ingat  Semua itu tidak akan bisa dilakukan tanpa diucapkan   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Segalanya akan lebih mudah apabila kita bisa melakukan yang tersulit, yaitu tegas pada diri sendiri..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Selalu bersyukur kepada Tuhan. Hidup ini bukan hanya tentang kita  bisa tetap BERDIRI, namun tentang BANGUN disaat kita  jatuh.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Selalu lakukan hal yg benar, dan yg benar pasti berbuah baik, karena kebenaran bersumber dari TUHAN.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Semangatlah karena kau tahu esok akan menjadi kesuksesanmu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Semua cobaan yang terjadi, terjadi atas kehendak Tuhan. Dan setiap kehendak Tuhan adalah untuk memuliakan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Semua manusia sempurna ketika mereka berhenti untuk mengeluh tentang kekurangan...   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Semua profesi tidak akan pernah mudah bagi mereka yang mudah menyerah.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Seorang yang bijaksana selalu mampu mengakui kesalahannya, mengambil hikmahnya dan berusaha keras memperbaikinya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Seribu perkataan dan pengetahuan tdk berarti tanpa ada satu tindakan yang nyata. ACTION    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sesekali, lihatlah masalahmu seakan-akan kita  melihat dari sisi orang lain. Dan lihatlah masalah orang lain seakan-akan itu masalahmu sendiri.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Seseorang dgn wawasan yg cukup untuk mengakui kekurangannya berada paling dekat dgn kesempurnaan   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sesuatu yg berarti, tak akan mudah kita  miliki. Semakin lama kita  menunggu, semakin kita  menghargai ketika dia jadi milikmu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setelah bisa menerima diri sendiri, akan lebih mudah lagi untuk menerima orang lain apa adanya..   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap detik yang berlalu akan jadi pengalaman berharga, jika kita mau menghargainya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap hari adalah perang. Antara dirimu dengan pikiran negatifmu. Sudah jutaan masalah muncul di dunia karena pikiran negatif. Dan sudah jutaan pula masalah terpecahkan karena pikiran positif.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap manusia pasti pernah berbuat salah, namun selama kita  mau melepaskan masa lalu, kita  akan punya masa depan yang cerah.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap masalah ada jalan keluarnya. kita  mungkin tak melihatnya, namun Tuhan tahu jalan keluarnya. Yakin dan percayalah padaNya   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap orang berbeda, unik dengan caranya. kita  harus menghargainya, tapi tak berarti kita  harus menyukai semuanya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Setiap orang pasti pernah melakukan salah, tapi ketika kita  terus melakukannya, kita  hanya mempermainkan dirimu sendiri.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Siapapun yg membaca ini, kita  tidak sendiri. Ada seseorang di luar sana yg menyayangimu lebih dari yg kita  tahu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Suatu hubungan berakhir, karena salah satu hati terlalu sedikit mencintai, dan atau terlalu banyak.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sukses dalam hidup tidak ditentukan oleh kartu baik, tapi dengan cara memainkan kartu buruk dengan baik   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Sukses dalam hidup tidak ditentukan oleh kartu baik,tapi dengan cara memainkan kartu buruk dengan baik   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Syukuri setiap kesulitan. Karena terkadang kesulitan mengantar kita pada hasil yang lebih baik dari apa yang kita bayangkan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 syukuri untuk semua apa yg terjadi hari ini dan tidurlah dengan nyenyak.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 tahu jika kita  tak mencobanya. Berikan seseorang kesempatan hingga dia berimu alasan tuk meninggalkannya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tahukah kita  ciri kegagalan? Ketika ada yang membicarakan negatif kita  setuju, ketika ada ide positif kita  ragu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tak ada rahasia utk menggapai sukses. Sukses itu dpt terjadi krn persiapan, kerja keras & mau belajar dari kegagalan   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tak ada yg lebih menyakitkan daripada mendengar seseorang hanya ingin Just A Friend ketika kita  ingin More Than Friend   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tak peduli seperti apa penampilan kita , percayalah, ada seseorang di luar sana yg akan mencintai kita , JustTheWayYouAre   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tapi setiap orang dapat mulai memperbaikinya mulai dari saat ini untuk sesuatu yang baru..   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tdk ada org yg dpt menyakitimu, kecuali mereka yg benar2 kau peduli, atau mereka yg tdk benar2 peduli padamu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang harus belajar dari burung Onta, dia tidak bisa terbang, tapi berlari dengan sangat kencang. Dibalik kekurangan, selalu tersimpan kelebihan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang kita  harus berpura-pura bahwa kita  tak peduli, karena kita  tak berarti apa-apa pada seseorang yg berarti segalanya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang kita  mencintai orang yg salah, kita  menderita karenanya. Namun karena kesalahan itu, kita  menemukan orang yg tepat.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang terasa pesimis,namun bangkitkanlah dengan bayangkan euforia yg nanti kalian raih   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang, diremehkan adalah cara terbaik untuk membangun semangat orang berjiwa besar untuk berhasil..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang, menangis hanya membuat matamu setingkat lebih jernih sebelum melihat kebahagiaan.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang, meski mampu meyakinkan dirimu bahwa dia bukan satu-satunya yg bisa buatmu bahagia, kita  tetap tak bisa melupakannya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang, yg buruk menurut kita adalah yg terbaik menurut Tuhan. Dan hanya kebesaran hati yg dapat menyikapi hal itu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Terkadang, yg tidak baik menurut kita adalah yg terbaik menurut Tuhan. Gunakan kebesaran hati untuk dapat menyikapi hal itu  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Ternyata Wanita yg paling cantik adalah wanita yg merasa bangga & nyaman menjadi dirinya sendiri.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tiada seorangpun yang bisa kembali untuk memperbaiki masa lalu dan mulai baru dari awal..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tiap cobaan datang, itu caraNya untuk membuatmu belajar ikhlas. Dan akan datang hari dimana kita akan duduk tenang dan menikmati kenangan hari ini   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidak ada beban yg berat kalau semua orang mau mengangkatnya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidak akan ada langkah ke-2 bila tak ada langkah pertama. , Just Do it    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidak perlu memfokuskan memikirkan orang yg membenci kita, karena masih banyak org yg menyayangi kita.    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidak perlu menunggu bintang jatuh untuk berdoa, karena Tuhan selalu siap mendengar doamu...   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidak pernah ada kata terlambat untuk memulai. Begitu juga untuk mengakhiri.    ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tidur terlalu malam dan bangun terlalu siang adalah penyebab paling utama kerusakaan hati.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tindakan benar memerlukan kekuatan besar.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Trkdg mereka yg tersenyum paling lebar adl mereka yg telah melalui masa tersulit & meneteskan air mata terpahit.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tuhan mencintaimu apa adanya, namun tak berarti kita tetap seperti adanya. Hidup ini anugerahNya. Jadilah pribadi yg lebih baik.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tuhan menganugerahkanmu air mata saat menangis agar di kemudian hari matamu lebih jernih saat melihat dunia.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tuhan mengirim seseorang dalam hidupmu tuk sebuah alasan, baik tuk belajar darinya atau tuk menjalani hidup ini bersamanya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tuhan tak akan pernah membiarkan rasa sakitmu lebih besar dari kebahagiaanmu. Percaya padaNya.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tuhan tidak pernah menjanjikan kesedihan untukmu. Dan jika kesedihan itu datang, itu karena kita  telah menghilangkan kebahagiaan dari dirimu.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Tulus dalam menggali potensi diri. Meniru hanya membuatmu menjadi orang lain, tak ada yg bisa dibanggakan. Jadi dirimu sendiri.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Uang bisa saja habis, tapi pengalamanmu tak kan pernah habis.. Bahkan ia selalu bertambah seiring waktu..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Uang tdk akan pernah cukup untuk menyembunyikan rasa sakit dan kecewa   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Untuk mencapai paru-paru, asap rokok hanya butuh waktu sekitar 3 detik dan langsung memacu jantung bekerja lebih keras.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Wahai saudaraku yang sedang galau hatinya, Bersyukurlah disaat kita  kehilangan seseorang yang tidak menyayangimu. Dan sesungguhnya yang merugi adalah mereka yang kehilangan orang menyayangi mereka.. Karena meskipun kita adalah saudagar, kita tidak akan pernah bisa membeli rasa sayang yang tulus.. Itu   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Waktu terus berjalan, belajarlah dari masa lalu, bersiaplah tuk masa depan, berikan yg terbaik untuk hari ini.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Wanita menangis bukan karena mereka lemah, namun karena mereka tak temukan kata tuk ungkapkan perasaan mereka.   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 WORKING......is to win the WAR to be THE KING   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 Yang kita  butuhkan untuk meraih cita2 adalah keinginan kuat yg akan membawa kita  menjadi pekerja keras   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 You can t go back and make new start.. But you can start now to make new end...   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ikutan komen di sini moga aja dapet gelas cantik .. :v ho ho ho .. ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Okeey deech .. :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
abiz ini aku boleh berkunjung ke status mu ea :v .. sip !   ',

 '👈💖👉 '.$nama.' -Oo.oO- '.$nama.' 

👈👀👉 Oo....................

'.$emojitor.' :

ada cerita lucu sob, baru dapet sms ..  SELAMAT!!!!!! anda pemenang door prize dari pasta gigi! , anda berhak untuk mendapatkan Mercedes Benz.. caranya cukup kirimkan 2 gigi depan anda beserta gusinya😹 😹 👼 👼 👼  ..  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ada promo Telkomsel gratis bicara kapan aja & dimana aja caranya tekan no tujuan lalu matiin hp, baru bicaralah sesuka anda, pasti gratis! ,..wwkwkk,, Piss dah !   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aku ikut aja deech .. (Y) ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Angkat jempol kaki yuuuk ,   '.$nama.'.... xxixi .. :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
apa kabar nwih ? ,  '.$nama.'.... kbarku alhamdulillah masih semangat😹 😹',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
AyoOo .. semangat !😹 😹:Jangan menyerah ketika yang diinginkan belum bisa didapatkan.  '.$nama.'.... Karena sesuatu yg berharga biasanya tidak mudah untuk diraih ..     ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ayooo angkat kaki muuu !!! , Ooupsz maap jarinya keseleo,  '.$nama.'.... hehe ... Ayooo angkat Jempolmu ! mampir juga dunk ke sini   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
bakar rumah aja yuuk biar tambah rame ..:v  👼 👼 👼  ..   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Banyak teman - banyak rejeki,  '.$nama.'.... semoga tidak sungkan untuk saling add & mempererat silaturahmi ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
biar gak lemes, aku kasih yang satu ini ya :v Jika percaya mampu meraih impianmu,  '.$nama.'.... maka teruslah berusaha. Keberhasilan itu akan memberimu kebahagiaan tak ternilai.,     ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
biar tambah aseek, gimana kalo aku like statusmu ,  '.$nama.'.... kamu like statusmu, terus kita like-like-an xixiii ...   :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Biarin dweh yang lain jarang like & komen di statusku,  '.$nama.'.... yang penting aku tetap ramah tuk menyapa sobatku semua, walaupun hanya sekedar di FB :v betul gak :v....  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bingung mau koment apalagi, aku share kata kata bijak aja ya  '.$nama.'.... , : Senyumlah, tinggalkan sedihmu. Bahagialah, lupakan takutmu. Sakit yg di rasa, tak setara dengan bahagia yg akan di dapat. Air mata tak selalu menunjukkan kesedihan, terkadang karena kita tertawa bahagia bersama sahabat terbaik kita., Amin.      ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
coba liat jempolna udah kriting beluum ?? hahahaaaa :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Coca-coca bagi2 🎁 hadiah  ! dapatkan 10rb/hari seumur hidup dr coca cola,,  '.$nama.'.... cara nya :kumpulkan 10 tutup botol coca cola & dpaku pd kayu lalu goyangknlah & brnyanyilah dilampu merah…  , ..:D WkWkWk , sorry Just Kidding  ,,   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
di kampung sebelah ada 💃 dangdutan loooh,. ikutan yuuuk hehee :D... :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
fb itu kan buat komunikasi , kalo ada status kita komen  ..😹 😹hehee kalo diem-dieman ntar di kira kita musuhan ,, Setuju Gak 😹 😹  '.$nama.'  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
fb kalo cuma di liatin doang, mendingan baca koran aja, bener ga tuh ,  '.$nama.'.... yuk komenan biar gak sepi ..😹 😹, ,hahaaa ,😹 😹atau kalo jempolna cape mau pake ini gratis koq :v =>   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hadir mu di sini udah di tunggu sma yg laen twuh,  '.$nama.'....   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Haseek ! =>   '.$nama.', udah nongol, kemana aja ? udah mampir ke statusku belom ??😹 😹 ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
👦 👧  ... anuu nya keliatan twuh hahaha',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Huuuft ..., kadang hp jadul ku loading lemot banget ,  '.$nama.'.... padahal hp ku udah pake antena parabola :v .. ,,   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Jangan buru-buru pergi ea,  '.$nama.'.... ikut komen lagi biar tambah rame di sini  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jumpa lagi sma =>   '.$nama.', smoga sehat selalu , Amiin .. :v   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kalo ada 👦 temen 👧 bikin statuz wajib di komen setuju gak😹 😹,  '.$nama.'....  biar ga di kira sombong gitu😹 😹hehee..  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu emang baik hati , selalu hadir di status 👦 temen 👧 TOP Deh (Y) ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu robot bukan ??  👈😷👉',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu robot jga ea ? :v aku bot looh .. =>  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
karena kamu udah hadir di sini, aku doain cepet punya rumah mewah, kapal pesiar, dan yang terakhir saya doain tetep jadi orang baik hehee ... mau gak ? :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
karena udah hadir, aku doain banyak rejeki . Amin   '.$nama.'.... ku tunggu kehadiranmu ea😹 😹',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kenalin dunk aku bot =>  ,  '.$nama.'.... kalo kamu robot satria Bj hitam ea,  Xxixi .. :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
komen di statuz aku jga duuunk,  '.$nama.'.... tambah seru looh kalo kamu hadir di sini  :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
komen lagi doong😹 😹 ...  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Lanjruuuut ...   '.$nama.' :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
maap bangeet aku lagi off line nieh....  '.$nama.'.... belum sempat on line aku....biar robot yang nemenin kamu ya 😱 😱 😱 😱 wakaka .. :v  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
maap ya kadang suka telat bales komen  '.$nama.'...., sinyal hp ku kadang ngilang , padahal fb-an udah di atas genteng neh..😹 😹hehe ,,   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
makasih ea udah nemenin komen,😹 😹,  '.$nama.'.... jadi tambah asik  .. he he😹 😹 ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mampir duunk ke statusku,  '.$nama.'.... nanti tak kenalin ma 👦 temen 👧 👦 temen 👧 aku banyaak loh ... hehee!😹 😹  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mampir juga ke sini   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau donk kenalin aku sma 👦 temen 👧 yg laeen  '.$nama.'.... biar aku banyak 👦 temen 👧 juga kaya kamu .. :v  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Mo telepon gratis dari operator Fren ?? …  '.$nama.'.... caranya gini bilang aja FREN pinjem telpon donk! , ..😹 😹xixii ,,   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mumpung kita ketemu ,  '.$nama.'.... saya undang mampir ke status ku ea  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mumpung yg punya fb gk ada,  '.$nama.'.... kita komen yg buanyak yuuk biar ramee  hahaaaa :D...   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
padahal ak tuh gak pelit-pelit amat buat jempol & komen di status 👦 temen 👧  '.$nama.'.... , tapi kalo aku bikin statuz mereka jarang komen ya ,,😹 😹hahahaa ..   ',        
'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Semangat ,, semangaat ,, semagaat =>  : “ Semoga kita mendapat cukup kebahagiaan untuk membuat kita bahagia, cukup cobaan untuk membuat kita kuat, cukup penderitaan untuk membuat kita menjadi manusia yang sesungguhnya, dan cukup harapan untuk membuat kita positif terhadap kehidupan. gmna dengan kata kata bijak setuju gak sob  ,👈😷👉,     ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
semoga aktivitasnya lancar hehee ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
sesama bot di larang saling mendahului ya,.. hehee!😹 😹=>  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
setuju aja deh, daripada benjol xixi .. :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
setuju gak ea ? :v :v bot na mikir :v  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Silaturahmi sesama teman fb harus tetap di jaga,  '.$nama.'.... makanya kalo ada 👦 temen 👧 bikin status kita jempolin dan komen😹 😹setuju gak :D, .....   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Sip ! setuju aja deh, daripada robot na benjol xixi .. :v  =>  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
slalu hadir di disini, kasih apa yaaa biar tambah baik hati lgi, ,, hohohooo   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Sssst ,... jangan bilang-bilang boss, kalo aku keluyuran kesini yaa,  plissss, plissss banget yaa... yaa   '.$nama.'.... :( :( ntar aku di bilang bot nakal :( ROBOT FACEBOOK   ',
''.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ssst..! sini aku bisikin, -> abis komen disini pulang dapet amplop gak ea ?? ssstt ,..  '.$nama.'.... jangan keras-keras jawabna ntar kedengeran tuan rumah :v  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tadinya mo komen kya gitu juga, udah kduluan,.. ntar dulu ,  '.$nama.'.... mo mikir kira-kira komen apalagi yaaa :v xixxiii .. ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
👦 temen 👧 yang baik hati selalu ramah menyapa status 👦 temen 👧 , mantab ! ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
temenin aku komen di sini ea biar gk sepi,  '.$nama.'.... jangan kemana-mana dunk, kalo mau kemana-mana ntar tak gendong ... :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah hadir , :v jadi tambah rame dech :v  '.$nama.'.... mampir juga dong ke statusku  ... :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah hadir.... makasih',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Udah mampir ke statusku belum :D '.$nama.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah pencet tombol like ? :O cepetan dikit ea ..   '.$nama.' ntar gk kebagian sma yang laen :v xixii.. :v ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Walaupun kalo aku bikin status jarang di komen sama yg laen, bagiku selalu berusaha bersikap ramah sama semua orang itu penting  '.$nama.'.... makanya aku tetep komen😹 😹setuju gak :D,  .....  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Yang laen pada kmana ya , koq sepi hehee😹 😹   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aaah   '.$nama.' bisa aja deeee '.$emojitor.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ampe jempol Keriting Oeee haha...  '.$nama.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
asal jangan tuing tuing aja 👈😷👉   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Asal kan Jangan Hadir bersama pak RT aja   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Baca Komen   '.$nama.' Rasa nya adem hehe',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
besok jempol nya di bonding ea   '.$nama.' wkwkwk',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bingung Mau jawab Apa   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
cie cie cie   '.$nama.' lagi ngrumpi ya? ngrumpiin apa nich ? ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Dulu Saya menderita kencing batu... setelah baca komen dari   '.$nama.' Batunya saya kumpulin buat bangun Rumah.... Terima kasih   '.$nama.' wkwkwk',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Dulu Saya suka makan roti.... setelah baca komen   '.$nama.' Saya jadi suka makan batu.... Terima kasih   '.$nama.' wkwkwkwk',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Dulu Saya susah tidur... Setelah baca komen dari   '.$nama.' saya Jarang mandi.... wkwkwk',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
dwuh   '.$nama.' aku udah cape sebenernya mau ngomen...tapi berhubung lagi pada kumpul...yuck mari dach',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Eeh ada !   '.$nama.' => udah mampir ke statusku belum😹 😹  ...  ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ehmm.. koq pada diem, !! (Y)  main jempol-jempolan yuuk :v di sini   ..   '.$nama.'   ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Haadweeeh !komen teruz ...,   '.$nama.' malah lupa dari kemaren mo update statuz .. :v xixiii ..',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Hadeeeh :v   '.$nama.' robot sya keluyuran ampe ke sini,..hahaaa.. maap ya sobatku   '.$nama.' => jika komen gk nyambung, maklum cuma robot komen .. :v, jika ada yg penting silahkan inbox saya   ..    ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hadiah 🎁 sendal jepit bakar buat   '.$nama.' yang udah hadir .... wkwkwk kaaabuuur',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hehe   '.$nama.' gak cape apa fb an terus? ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hehe   '.$nama.' udah lemes belum .. aku temenin ngobrol ya?? ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jempol mu luar biasa   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jempolku udah kejang-kejang ampe masuk UGD tetep hadir di status mu   '.$nama.' , hahaahaa :v , jangan lupa mampir ya     ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu juga komen nya gak nyambung   '.$nama.' 👦 👧  ...',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Kamu Koq baek banget sich   '.$nama.'.... Selalu Hadir',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu Like status ku   '.$nama.' aku like status mu trus kita Like Like an yuk','Kikuk Kikuk ... hehe',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Lagi bahas apaan sich   '.$nama.' aku pengen ikut ngobrol nich ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Maap '.$nama.'  Baru off line nieh.... belum sempat on line saya....  '.$nama.'.... biar robot yang nemenin kamu ya 😱 😱 😱 😱 wakaka',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
maap pemirsa lagi gak bisa online jadi robot yang wakil in komen dech :v   '.$nama.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau di pijitin jari nya   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
meski aku cuma robot, tapi juga tetep mikir lho  '.$nama.'... ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ndak krriting twuh jempol nya komen terus   '.$nama.' wkwkwk ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Oke siiip ...   '.$nama.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
rehat dulu   '.$nama.' biar capex nya ilang ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
robot mu mantap   '.$nama.' minta script nya dunk wkwkwk',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Salut dweh   '.$nama.'... meski jari nya keriting tetep hadir makasih eaaa ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Seneng dweh kalo ada   '.$nama.' ntar Komen lagi eaaaaa 👈😷👉 ....',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Sesama robot Harus rukun  ea   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
siT sUiiiiiiit..................!!!   '.$nama.' ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tadi kesini nya sambil bawa 🍔 makanan  gak   '.$nama.' hehe... ..!!',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tenang   '.$nama.' sini jari nya aku setrika 😱 😱 wakaka ',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Trimz waaaaa   '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah coba curhat sama 👦 temen 👧 belum? atau mau curhat sama aku?   '.$nama.'  Pizz',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
waaaaaah komen nya gak nyambung   '.$nama.' 👦 👧  ...',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
'.$ucapan.'   '.$nama.' :D ......  ', 

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Walah kemana   '.$nama.'...?',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Weeeeeeeeeeeee   '.$nama.' udah hadirrrrr....  '.$nama.'',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Wew masih jam segini   '.$nama.' mau kemana.?',

'
👈👀👉 Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
wuhuuu lagi ngomongin apa sih ...   '.$nama.' ? kayaknya asik banget :v ',


);

$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 01) $_sambutan = "Met dini hari .";
else if ($_time > 24) $_sambutan = "Good merem . ";
else $_sambutan = "Selamat Pagi  ";

$gentime = microtime();
$gentime = explode(' ',$gentime);
$gentime = $gentime[0];
$pg_end = $gentime;
$totaltime = ($pg_end - $pg_start);
$showtime = number_format($totaltime, 1, '.', '');

$hari=gmdate("D", time()+60*60*7);
if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Sunday"; }
if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Monday"; }
if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Tuesday"; }
if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Wednesday"; }
if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Thursday"; }
if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Friday"; }
if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Saturday"; }
$jame=" ".gmdate("g:i:s a", time()+60*60*7);
$tgl=" ".gmdate("j - m - Y", time()+60*60*7);


$habiscomment1=array(
'

Happy '.$hari.' :*
..............................................Oo 👈👀👉 
PoWered.® Gentho-Bot» Gentho-Bot   
',
'

Salam Robot :|] ...
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
VIP Account ® Gentho-Bot   
',
'

'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
Official Profile® Gentho-Bot   
',
'

Salam Persahabatan  :* ...
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
PoWered.® Gentho-Bot» Gentho-Bot   
',
'

Salam Silaturahmi ...
'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
Official Profile® Gentho-Bot   
',
'

Semoga Sukses ! 🎓 amin .
..............................................Oo 👈👀👉 
'.$hari.' » '.$tgl.' » '.$jame.'
VIP Account ® Gentho-Bot   
',
'

Salkombot :|] ...
'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
PoWered.® Gentho-Bot» Gentho-Bot   
',
'

Salkomsel ☀ ...
'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
Official Profile Gentho-Bot   
',

'

Salam Jempol 
'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
VIP Account ® Gentho-Bot   
',
'

Salam boters :|] ...
..............................................Oo 👈👀👉 
PoWered.® Gentho-Bot   
',
'

'.$hari.' » '.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
© Official Profile® Gentho-Bot   
',
'

Salam kompak (Y) ..
Have a nice '.$hari.' :*
'.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
VIP Account ® Gentho-Bot   
',
'

Sukses selalu untukmu ..
..............................................Oo 👈👀👉 
'.$tgl.' » '.$jame.' »
PoWered.® Gentho-Bot   
',
'

Happy '.$hari.' :*
'.$tgl.' » '.$jame.' »
..............................................Oo 👈👀👉 
© Official Profile® Gentho-Bot   
',
'

Add / Ikuti / Follow Me 👈😜👉
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
VIP Account ® Gentho-Bot   
',
'

Salam santun :) . .
..............................................Oo 👈👀👉 
https://m.facebook.com/profile.php
PoWered.® Gentho-Bot   
',
);
$habiscomment2=$habiscomment1[rand(0,count($habiscomment1)-1)];
$habiscomment3='<3 ';

$message1 = ''.$arr_mess[rand(0,count($arr_mess)-1)];

$message =($habiscomment3.$nama.$message1.$habiscomment2);                           


if($com[data][$c-1][from][id] != $me[id]) {
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'&method=post');
auto('https://graph.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$access_token.'&method=post');
}
}
}
}
}
function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>
