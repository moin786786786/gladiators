﻿﻿<?php
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

if(file_exists('cmy_log')){
$log=json_encode(file('cmy_log'));
}else{
$log='';
}
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met Online aja .. ','Patroli jempol - jangan lupa like back ya ... ','Selamat Pagi - qo belom tidur ..','Jempolku udah keriting .. kalo ada waktu mampir ke statusku ea ... ','Selamat Pagii ..... ','Good Morning ','Breakfast time my friends .....','Sarapan pagi yuuuk ... ','Met Pagi ','Coffee break ..','Makan siang yuk ....','Lunch time sobat ..','Met Siang aja ....','Good afternoon ..','Selamat beraktivitas kembali ...','Met Sore','Selamat Sore ','Met Petang','Santai dulu ........','Met Malem ','Relax time ...','Good night ...','Met rehat .......','Good merem  ..','Waktunya bobo .. ',);

$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);

$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat=json_decode(auto('https://graph.facebook.com/me/home?fields=id,message,created_time,from,comments,type&access_token='.$access_token.'&offset=0&limit=15'),true);

for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
if($stat[data][$i-1][from][id] != $me[id]){
$x=$stat[data][$i-1][id].'  ';
$y = fopen('cmy_log','a');
fwrite($y,$x);
fclose($y);

$s=$stat[data][$i-1][message];

$inc=array('komen_acak.php',);
include $inc[rand(0,count($inc)-1)];
$komentar = $text[rand(0,count($text)-1)];

$gen=json_decode(auto('http://graph.facebook.com/'.$stat[data][$i-1][from][id].'?fields=gender'),true);

if($gen[gender] == 'male'){
$arr_gen = array('Mas ','Mas ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}else{
$arr_gen = array(' ',' ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}

$exp_nam = explode(' ',$stat[data][$i-1][from][name]);
$nama = $gender.' '.$exp_nam[0];
$tags = explode(' ',$stat[data][$i-1][from][id]);
$tagged_name = ' @['.$tags[0].':1] ';

if($stat[data][$i-1][type] == 'photo' ){
$acak_komen= array(
''.$komentar.' '.$ucapan.' ',
''.$ucapan.' '.$komentar.' ',
''.$ucapan.' ',
''.$komentar.' ',
);
}else{
$acak_komen = array(
''.$komentar.' '.$ucapan.' ',
''.$ucapan.' '.$komentar.' ',
''.$ucapan.' ',
''.$komentar.' ',
); 

}

$message = $acak_komen[rand(0,count($acak_komen)-1)];

auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'&method=post');
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
echo $stat[data][$i-1][from][name].'=> '.htmlspecialchars($stat[data][$i-1][message]).'
Komeng => '.$message.'';
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}

?>