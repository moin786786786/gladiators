?<?php
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met dini ?? hari . ','Met jelang pagi . ','Selamat ?? Pagi ?? ','Met ?? Pagi ?? ','????? ','?~ ','Breakfast time ??????? . ','Met Tifitas ?? ','Have a nice day ? . ','Good ? Day . ','Time for ??????? lunch . ','Met makan ??????? siang ? .','Good siang ? . ','Met jelang sore . ','Good afternoon . ','?~ ','Salam kompak ??jempoler?? ','Good evening . ','Time for ??????? dinner . ','Met ?? Online ~ . ','Met ?? rehat .','Have ?? nice ?? dream . ','Good ?? night ?? ','Good merem ???? ','Met rehat ???? ',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);
$me = json_decode(auto('https://graph.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.facebook.com/me/feed?fields=id&access_token='.$access_token.'&offset=0&limit=10'),true);
$log = json_encode(file('res_own_status1'));
for($i=1;$i<=count($stat[data]);$i++){
$com = json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=25&fields=id,message,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
$dat = explode($com[data][$c-1][id],$log);
if(count($dat) > 1){
echo'Done<br/>';
}else{
$logx = $com[data][$c-1][id].'__';
$logy = fopen('res_own_status1','a');
fwrite($logy,$logx);
fclose($logy);
$qwerty = array('0','1','2','3','4','5','6','7','8','9','10',);
$emo = array(' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',);

$inc=array('emojitor.php',);
include $inc[rand(0,count($inc)-1)];
$mess = $text[rand(0,count($text)-1)];
$emojitor = str_replace($qwerty,$emo,$mess);		

$gen = json_decode(auto('http://graph.facebook.com/'.$com[data][$c-1][from][id].'?fields=gender'),true);


if($gen[gender] == 'male'){
$arr_gen = array('?? Mas ','?? Mas ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}else{
$arr_gen = array('<3 ','<3 ','<3 ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}

$exp_nam = explode(' ',$com[data][$c-1][from][name]);
$nama = $gender.' '.$exp_nam[0];
$tags = explode(' ',$com[data][$c-1][from][id]);
$tagged_name = ' @['.$tags[0].':1] ';


$kata=$com[data][$c-1][message];
if(ereg('MAAF',$kata) || ereg('maaf',$kata) || ereg('Maaf',$kata)){
$arr_mess = array( 
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Jiaaaaaaaaah... pake maap segala ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
eaaa.... gak papa udah aku maaf in koq... 
ntar komen lagi ea....?? ????????'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aduuuuh tiada maap bagi mu ...?? ??
gimana nieh... wkwkwkwk'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
keliling kampung dulu 5x...
ntar di maapin ... :v :v wkwkwkwk'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
yeeee enak aja minta maaf... Nyanyi dulu
?? ?? nang ning ning nang oooo.... 
5X wkwkwk'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
maaf...?? ... emang kenapa ?'.$nama,

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
masama .. ?? ?? Aku ?? ??juga minta maaf... 
ya ??'.$nama.' ',
);
}else{
if(ereg('ASSALAM',$kata) || ereg('Assalamualaikum',$kata) || ereg('Askum',$kata) || ereg('assalamualaikum',$kata) || ereg('askum',$kata) || ereg('ASKUM',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Waalaikum salam... '.$nama.' ',
);
}else{
if(ereg('mandi',$kata) || ereg('pake celana',$kata) || ereg('mande',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3idiiih...
?? ?? parno ?? ?? ?? '.$nama.' ',
'
??????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Yaaaa udah sana .........
mandi duluan??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Belom mandi ya ??wkwwkwk .......... 
awas?? ?? anuu nya keliatan twuh hahaha'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
lohh?? ?? mandi kuq gak ajak ajak.....
....hahaha piss'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah cepet sana mandi ......... 
bentar lagi pacarmu jemput wkwkwk....'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tumben... ?? ?? mandi ???????'.$nama.' ',
);
}else{
if(ereg('no1',$kata) || ereg('No-1',$kata) || ereg('no-1',$kata) || ereg('no 1',$kata) || ereg('pertamanya',$kata) || ereg('yg tercepat',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
waaaaaah?? ?? no 1 yaaa ....
cuapek dweeh wkwkwk....'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hadiah buat?? ?? yang jadi no pertama .....
plaaaaackk.... wkwkwk kaaabuuur'.$nama.' ',
);
}else{
if(ereg('ROBOT',$kata) || ereg('robot',$kata) || ereg('bot',$kata) || ereg('BOT',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
robot?? ?? minta script nya dunk '.$nama.' :P .... ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
robot :|] keluyuran mulu sih......
?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 ?? ?? :|] robot kamu siapa yang bikin
hahaha '.$nama.' ',
$ucapan.'?? ?? :|] robot'.$nama.' ',
);
}else{

if(ereg('cinta',$kata) || ereg('love',$kata) || ereg('pacaran',$kata) || ereg('kekasih',$kata) || ereg('kangen',$kata) || ereg('kasmaran',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
?? ????????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aduuuh?? ?? makasih deh hahahaaaaaa ..'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
haddooooh?? ??ngomong apaan siih 
?????? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
pokok nya jempol... ?? ?? ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
oooooo love ea?? ??hahaha'.$nama.' ',
);
}else{
if(ereg('kenapa',$kata) || ereg('knapa',$kata) || ereg('knp',$kata) || ereg('kenapakah',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kenapa ? tau ach gelap '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kena sesuatu nich '.$nama,
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
gak kenapa-kenapa... '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kenapa ea?? ??? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Mau tau aja urusan robot'.$nama.' ',
);
}else{
if(ereg('mengapa',$kata) || ereg('mengpakah',$kata) || ereg('mgapa',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mengapa ea? sek sek sek tak mikir'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
karena ?? ??saya juga robot ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu robot ?'.$nama.' ',
);
}else{
if(ereg('haha',$kata) || ereg('hihi',$kata) || ereg('wkwk',$kata) || ereg('wakaka',$kata) || ereg('hehe',$kata) || ereg('xixi',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ngakak ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
malah mrengez ??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
looohhh malah ketawa ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
loooohhh robot nya ketawa hahaha'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 aku serius pleeend jangan ketawa dunkkkk... 
wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 koq ketawa ada yang aneh ea hehe'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 wkwkwkwkwk juga'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah udah jangan ketawa mulu... 
 ?? ??malu tuh banyak orang 
?? ?? ?? '.$nama.' ',
);
}else{
if(ereg(' WIB',$kata) || ereg(' pm',$kata) || ereg(' am',$kata) || ereg('tanggal',$kata) || ereg('jam',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Jam nya bener gak tuh...?? ??'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
apa an twuh?? ??koq ada jam nya segala'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
pasti?? ??nich orang yang tepat waktu... 
ampe komen pun di kasih jam...??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu tukang jam keliling ya 
tiap komen kamu nyebutin waktu?? ??wkwkwkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
lho,,?? ??itu robot atau 
tukang jam keliling ya ?? wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aduuuh?? ??jam nya bener gak tuh 
wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
haddooooh?? ??robot na gaul 
ada jam na segala . . . .
coba di kasih peci sekalian wkwkwk '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
lho lho...?? ??robotmu juga pake jam ya ?? sama dong 
:P'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Jam nya tukeran yuk ?? ??..'.$nama.' ',
);
}else{
if(ereg('kemana',$kata) || ereg('kmana',$kata) || ereg('buru2',$kata) || ereg('ditinggal',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
eaa nich?? ??robot nya ngantuk... 
bye ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kemana kemana kemana.... assseeekk 
ting ting punya pleend hehe'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah ngantuk aku ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
byee.... ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
turru sek yo ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau bobok aku. ?? .. mau ikut ta'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
?? aku ikut ya '.$nama,
);
}else{
if(ereg('kadir',$kata) || ereg('hadir',$kata) || ereg('HADIR',$kata) || ereg('ABSEN',$kata) || ereg('absen',$kata) || ereg('Absen',$kata)){
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Timz ya?? ??udah hadir...'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
seneng dweh kalo?? ??hadir'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah aku tunggu kehadiran mu 
 ?? ??hehe... '.$ucapan.'..!!'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
 udah hadir.... makasih'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hadir kemana?? ????? wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
?? ??Kamu bawa anu ea....?? 
 koq setiap?? ??hadir bawaan nya 
 kepengen anu gitu...wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
asseeeek?? ??hadirrr... 
gak jadi galau lah aku... ??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
betapa sepi nya tanpa kehadiran mu 
 ?? ??wkwkwkwk'.$nama.' ',
);
}else{
if(ereg('https',$kata) || ereg('www',$kata) || ereg('http',$kata) || ereg('HTTP',$kata) || ereg('Http',$kata)){
$arr_mess=array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Link apaan twuh Gan ?? BERBAHAYA gak ??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Situs apa an twuh?? Jangan jangan 
situs anu ya ?? ??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
di situs itu ada ?? makanan nya gak twuh gan 
??????'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
apa an yach isi situsnya ?? 
Jadi penasaran dweeh ??????'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
situs apa an twuh hayooo ?? 
Jangan jangan situs parno ya ?? wkwkwkwk '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Link nya boleh di pencet pencet ndak twuh 
?????? '.$nama.' ',
);
}else{
if(ereg('OFF',$kata) || ereg('off',$kata) || ereg('ofline',$kata) || ereg('offline',$kata) || ereg('Offline',$kata) || ereg('Off',$kata)){
$arr_mess=array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Waaaah?? ??hebat.... 
padahal lagi off line koq bisa comment 
gimana cara nya twuh?? ??????....'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
sama?? ??aku juga gie Off line 
koq'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau off line atau online yang penting 
udah comment aku udah seneng banget koq 
 ...:D yakin dah zumpah...!!! 
??????'.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
yaaah?? ??off line mulu nich
......'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
owww jadi?? ??robot ea.... 
sama kalo giitu ?? ?? ?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
waduh?? ??jadi robot'.$nama.' ',
);
}else{
if(ereg('Keriting',$kata) || ereg('kriting',$kata) || ereg('Kriting',$kata) || ereg('Kesleo',$kata) || ereg('kriting',$kata) || ereg('kesleo',$kata)){
$arr_mess=array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Salut dweh...?? ??meski 
jari nya keriting tetep hadir 
makasih eaaa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tenang?? ??sini jari nya 
aku setrika ?? ?? wakaka'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Uuuuu kacian keriting ea...?? ??
sama kalo gitu'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau di pijitin jari nya'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
besok jempol nya di bonding ea 
 ?? ??wkwkwk'.$nama.' ',
);
}else{
if(ereg('like',$kata) || ereg('JEMPOL',$kata) || ereg('LIKE',$kata) || ereg('jempol',$kata) || ereg('Jempol',$kata) || ereg('suka',$kata)){
$arr_mess=array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
terima kasih'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jempol mu luar biasa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ndak krriting twuh jempol nya 
wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ok thankz for like this... wekekekeke'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
makasih udah like'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
bener nich'.$nama.' ',
);
}else{
$arr_mess = array(
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3

?????? Oo....................
'.$emojitor.' : 

Apa artinya kaki bila kau tak berjalan , 
Apa guna mata bila tak menatap masa depan , 
Untuk apa bermimpi, bila kau tak melangkah , 
Untuk apa kesempatan bila tak ambil celah '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Apapun yang kitarencanakan, 
apapun yang kitaingin lakukan, 
awalilah dengan doa. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Apapun yg kita terima adl akibat dari 
yg telah kita lakukan. Untuk itu, 
lakukanlah yg terbaik agar mendapat 
hasil yg baik pula. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Apapun yg telah kitalakukan, 
apapun kesalahanmu, kitaakan selalu 
menemukan kata maaf dalam 
hati seorang Ibu. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Apapun yg terjadi, nikmati hidup ini. 
Hapus air mata, berikan senyummu. 
Kadang, senyum terindah datang 
setelah air mata penuh luka '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bahagia bukan milik dia yg hebat 
dalam segalanya, namun dia yg mampu 
temukan hal sederhana dlm hidupnya 
dan tetap bersyukur. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bahagia dan memilih sendiri jalan hidup 
adalah sesuatu yg harus kitasadari. 
Jangan biarkan seorangpun yg menentukannya 
untukmu. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bahagia tak datang karena kita
mendapatkan apa yg tak pernah kitamiliki,
 namun karena kitamenghargai apa yg 
 telah kitamiliki. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bahagialah dengan apa yang kitamiliki. 
Jangan melepasnya hanya karena rasa takut. 
kitamungkin tak akan mendapatkannya 
kembali'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Banyak orang yang menggebu-gebu saat 
membayangkan mimpinya,tapi lemah 
dalam mengejarnya.'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Barangsiapa membawa berita tentang 
orang lain kepadamu, maka dia akan 
membawa berita tentang dirimu kepada 
orang lain '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bebaskan dirimu dari belenggu masa lalu. 
Hiduplah hari ini tuk menciptakan 
masa depan yg lebih baik. Miliki hati, 
jadikan berarti. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Beda pendapat sering dipicu oleh beda 
pendapatan. ??????e?? ??___ '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Belajar memang melelahkan,
namun lebih lelah nanti kelak 
jikalau saat ini tidak belajar '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berbahagialah mereka yang dapat bertahan 
di saat menerima keberuntungan 
dan ketidakberuntungan. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berfikir itu cahaya, kelalaian itu kegelapan, 
kejahilan itu kesesatan & manusia yg paling hina 
ialah orang yg menganiaya orang bawahannya '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berhenti berusaha tuk jadi yg sempurna. 
Temukan dia yg tahu semua kelemahanmu 
tapi tetap ingin menjadi bagian hidupmu. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berhenti mencari yg sempurna tuk dicintai, 
karena yg kitabutuh hanya dia yg tahu betapa 
beruntung dia ketika bersamamu. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berhenti sia-siakan hidup menunggu dia yg 
tak akan pernah jadi milikmu. Hidupmu 
terlalu berharga tuk itu. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berhentilah berprasangka buruk. 
Karena prasangka itulah yang akan membuatmu 
menyesal dikemudian hari. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berimajinasilah seperti anak-anak, 
semangat ala pemuda, dan bijaksana layaknya 
orang dewasa.. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
berlarilah sekencang mungkin,
realisasikan lah target yg telah dicanangkan 
untuk hidup yg lebih baik '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berlarut dalam kesedihan tak akan bisa 
membuatmu bangkit. Hapus air matamu, 
segera bergerak maju'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berpikir dengan hati yang jernih, 
agar semua terlihat lebih jelas. 
Emosi timbul bukan karena tidak punya hati, 
tapi karena hati yang ada tidak digunakan 
dan dijaga dengan semestinya. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
BERPIKIR POSITIF dapat menghancurkan 
semua tembok pemisah antaratidak bisa
danbisa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bersedih dengan orang yg tepat lebih baik 
daripada berbahagia dengan orang yg salah 
setuju gak ?'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bersyukurlah untuk hari kemarin.. 
Berdoalah untuk hari esok.. 
Berjuanglah untuk hari ini.. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berusaha keras adalah cara terbaik 
untuk mengamini tiap doa yang telah 
kau ucapkan.'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berusaha menjadi yang terbaik itu penting. 
Tapi yang lebih penting adalah mampu membuat 
orang-orang di sekeliling kita merasa menjadi 
diri mereka yang yang terbaik. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Berusahalah terus jangan pantang menyerah 
seakan akan besok kau akan mendapatkan 
kebahagian tak terkira '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bkn mereka yg terkuat & terbesar yg akan 
dapat mempertahankan eksistensinya. 
Tapi hanya mereka yg mampu beradaptasi 
terhadap perubahan '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jempol ku udah kriting plend plend hehe'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu Like status ku aku like status mu 
trus kita Like Like an yuk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Kikuk Kikuk ... hehe'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
makasih udah like '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ndak krriting twuh jempol nya wkwkwk '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
padahal ak tuh gak pelit-pelit amat 
buat jempol & komen di status temen, 
tapi kalo aku bikin statuz mereka 
jarang komen ya ,,?? ??hahahaa .. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Semangat ,, semangaat ,, semagaat??????� 
Semoga kita mendapat cukup kebahagiaan untuk 
membuat kita bahagia, cukup cobaan untuk 
membuat kita kuat, cukup penderitaan untuk 
membuat kita menjadi manusia yang sesungguhnya, 
dan cukup harapan untuk membuat kita positif 
terhadap kehidupan. 
gmna dengan kata kata bijak setuju gak sob 
?????? '.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
semoga aktivitasnya lancar hehee '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
sesama bot di larang saling mendahului ya,.. 
hehee!?? ??:P'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
setuju aja deh, daripada benjol xixi .. :v '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
setuju gak ea ? :v :v bot na mikir :v'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Silaturahmi sesama teman fb harus 
tetap di jaga, makanya kalo ada temen 
bikin status kita jempolin dan komen?? ??
setuju gak :D, ..... '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Sip ! setuju aja deh, daripada robot na 
benjol xixi .. :v ?????? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
slalu hadir di disini, kasih apa yaaa biar 
tambah baik hati lgi, ,, hohohooo '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Suka Sekali ya ama aku ??????, tiap bikin 
status kamu slalu hadir .. wkwkwk .. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
temen yang baik hati selalu ramah menyapa 
status temen , mantab ! '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
temenin aku komen di sini ea biar gk sepi,
jangan kemana-mana dunk, 
kalo mau kemana-mana ntar tak gendong 
.. :v '.$nama.' ',

'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah hadir , :v jadi tambah rame dech 
:v :v '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah hadir.... makasih'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah pencet tombol like ? O cepetan dikit ea 
.. ntar gk kebagian sma yang laen :v 
xixii.. :v '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Walaupun kalo aku bikin status jarang 
di komen sama yg laen, bagiku selalu 
berusaha bersikap ramah sama semua 
orang itu penting makanya aku tetep komen
?? ??setuju gak :D,.....'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Yang laen pada kmana ya , koq sepi hehee?? ??:D,, '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
:D heheee .. '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
aaaaaaaaah ada...?? ??Thankz 
 ?? ??udah hadir...'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ampe jempol Keriting Oeee haha...'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
asal jangan tuing tuing aja ??????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Asal kan Jangan Hadir 
nagih utang aja wkwkwwkk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Asal kan Jangan Hadir bawa pak RT aja 
?? ??ii ..'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Asal kan Jangan Hadir bersama 
tukang kreditajawkwkwwk
,, '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Baca Komen?? ??Rasa nya adem hehe'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
besok jempol nya di bonding ea 
wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Bingung Mau jawab Apa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
cie cie cie lagi ngrumpi ya? 
ngrumpiin apa nich ? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Dulu Saya suka makan roti.... setelah 
baca komen Saya jadi suka makan batu.... 
Terima kasih 
wkwkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Dulu Saya susah tidur... Setelah baca 
komen dari?? ??saya Jarang mandi
.... wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
dwuh aku udah cape sebenernya 
mau ngomen...tapi berhubung lagi pada kumpul
...yuck mari dach'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ehmm.. koq pada diem, !! main jempol-jempolan 
yuuk (Y):v '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Haadweeehkomen teruz ..., 
malah lupa dari kemaren mo update 
statuz .. :v xixiii ..'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hadiah sendal jepit bakar buat 
yang udah hadir .... wkwkwk kaaabuuur'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hehe gak cape apa fb an terus? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
hehe udah lemes belum .. 
aku temenin ngobrol ya?? '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
jempol mu luar biasa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Kamu Koq baek banget sich.... 
Selalu Hadir'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
kamu Like status ku aku like status mu 
trus kita Like Like an yuk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Kikuk Kikuk Hehe.... '.$ucapan,
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Lhoooo?? ??nongol Lagi hahahaaa ... 
betah ya disini ???????'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Maap.... Baru off line nieh.... 
belum sempat on line saya....biar robot 
yang nemenin kamu ya ?? ?? ?? ?? wakaka'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
maap pemirsa lagi gak bisa online jadi 
robot yang wakil in komen dech :v '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
mau di pijitin jari nya'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
meski aku cuma robot, tapi juga 
tetep mikir lho ... '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ndak krriting twuh jempol nya wkwkwk '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Ngopi dulu'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
ok thankz for like this... wekekekeke '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Oke?? ??Thankz udah Mampir'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Oke siiip ...'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Oke Tok Ezz?? ??Makasih eaaa'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
rehat dulu biar capex nya ilang '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
robot mu mantap minta script nya 
wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Salut dweh... meski jari nya 
keriting tetep hadir makasih eaaa '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Seneng Dweh?? ??udah comment'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Seneng dweh kalo ada 
ntar Komen lagi eaaaaa ?????? ....'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Sesama robot Harus rukunea'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
siT sUiiiiiiit..................!!!'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tadi kesini nya sambil bawa ?? makanangak 
hehe... ..!!'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
tenang sini jari nya aku 
setrika ?? ?? wakaka '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Thankz'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Tthankz ea?? ??udah mampir... 
'.$ucapan.' '.$nama,
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
udah coba curhat sama temen belum? atau 
mau curhat sama aku?Pizz'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
wadaw wadaw wadaw....?? ??wkwkwk'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Walah kemana...?'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Weeeeeeeeeeeee?? ??udah hadirrrrr....
 '.$ucapan.''.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Weeeeeeeeeeeee udah hadirrrrr.
... '.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
Wew masih jam segini mau kemana.?'.$nama.' ',
'
?????? Oo....................
'.$emojitor.' : 

'.$tagged_name.' <3
wuhuuu lagi ngomongin apa sih ... 
? kayaknya asik banget :v '.$nama.' ',

);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 01) $_sambutan = "Met dini hari .";
else if ($_time > 24) $_sambutan = "Good merem . ";
else $_sambutan = "Selamat Pagi";

$gentime = microtime();
$gentime = explode(' ',$gentime);
$gentime = $gentime[0];
$pg_end = $gentime;
$totaltime = ($pg_end - $pg_start);
$showtime = number_format($totaltime, 1, '.', '');

$hari=gmdate("D", time()+60*60*7);
if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Sunday"; }
if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Monday"; }
if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Tuesday"; }
if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Wednesday"; }
if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Thursday"; }
if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Friday"; }
if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Saturday"; }
$jame=" ".gmdate("g:i:s a", time()+60*60*7);
$tgl=" ".gmdate("j - m - Y", time()+60*60*7);

$habiscomment1=array(
'

<3 Happy '.$hari.' :*
..............................................Oo ?????? 
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salam Robot :|] ...
..............................................Oo ?????? 
https://m.facebook.com/profile.php
VIP Account � Gentho-Bot   
',
'

<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
https://m.facebook.com/profile.php
Official Profile� Gentho-Bot   
',
'

<3 Salam Persahabatan  :* ...
..............................................Oo ?????? 
https://m.facebook.com/profile.php
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salam Silaturahmi ...
'.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile� Gentho-Bot   
',
'

<3 Semoga Sukses ! ?? amin .
..............................................Oo ?????? 
'.$hari.' � '.$tgl.' � '.$jame.'
VIP Account � Gentho-Bot   
',
'

<3 Salkombot :|] ...
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salkomsel ? ...
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile Gentho-Bot   
',

'

<3 Salam Jempol ??????
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
VIP Account � Gentho-Bot   
',
'

<3 Salam boters :|] ...
..............................................Oo ?????? 
PoWered.� Gentho-Bot   
',
'

<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
https://m.facebook.com/profile.php
Official Profile� Gentho-Bot   
',
'

<3 Salam kompak (Y) ..
<3 Have a nice '.$hari.' :*
<3 '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
VIP Account � Gentho-Bot   
',
'

<3 Sukses selalu untukmu ..
..............................................Oo ?????? 
<3 '.$tgl.' � '.$jame.' �
PoWered.� Gentho-Bot   
',
'

<3 Happy '.$hari.' :*
<3 '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile� Gentho-Bot   
',
'

<3 Add / Ikuti / Follow Me ??????
..............................................Oo ?????? 
https://m.facebook.com/profile.php
VIP Account � Gentho-Bot   
',
'

<3 Salam santun :) . .
..............................................Oo ?????? 
https://m.facebook.com/profile.php
PoWered.� Gentho-Bot   
',
);
$habiscomment2=$habiscomment1[rand(0,count($habiscomment1)-1)];
$habiscomment3 = '<3 ';

$message= ' '
.$arr_mess[rand(0,count($arr_mess)-1)].'';

$message_zi =($habiscomment3.$nama.$message.$habiscomment2);

if($com[data][$c-1][from][id] != $me[id]) {
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message_zi).'&method=post');

auto('https://graph.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.facebook.com/'.$com[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.facebook.com/'.$com[data][$i-1][id].'/pokes?access_token='.$access_token.'&method=post');
}
}
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}

function getData($xurl){
 $xcx=curl_init();
 curl_setopt($xcx,CURLOPT_URL,$xurl);
 curl_setopt($xcx,CURLOPT_RETURNTRANSFER,1);
 curl_setopt($xcx, CURLOPT_COOKIEFILE,'coker_log');
 $xch = curl_exec($xcx);
 curl_close($xcx);
 return $xch; 
 }

?>