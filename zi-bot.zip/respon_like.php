?<?php
$fileAccess = file('my_token.txt');
$access_token=$fileAccess[0];

$notif = json_decode(auto('https://graph.facebook.com/fql?q='.urlencode('SELECT sender_id, title_text, object_id FROM notification WHERE recipient_id=me() AND is_hidden = 0').'&access_token='.$access_token),true);
if(file_exists('Responlike1')){
   $log = json_encode(file('Responlike2'));
   }else{
   $log='';
  }
for($i=1;$i<=count($notif[data])-1;$i++){
   if(ereg('likes your comment',$notif[data][$i-1][title_text])){
       if(!ereg($notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id],$log)){
           $x = $notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id].' ';
           $y = fopen('Responlike2','a');
fwrite($y,$x);
fclose($y);
$qwerty = array('0','1','2','3','4','5','6','7','8','9','10',);
$emo = array(' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',' ?? ',);
$inc=array('emojitor.php',);
include $inc[rand(0,count($inc)-1)];
$mess = $text[rand(0,count($text)-1)];
$emojitor = str_replace($qwerty,$emo,$mess);	

$sender_id = json_decode(auto('http://graph.facebook.com/'.$notif[data][$i-1][sender_id].'?fields=gender'),true);            

if($sender_id[middle_name] && strlen($sender_id[middle_name])>=3) {$nameto=$sender_id[middle_name];}
elseif($sender_id[first_name] && strlen($sender_id[first_name])>=3) {$nameto=$sender_id[first_name];}
elseif($sender_id[last_name] && strlen($sender_id[last_name])>=3) {$nameto=$sender_id[last_name];}

if($gen[gender] == 'male'){
$arr_gen = array('?? Mas ','?? Mas ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}else{
$arr_gen = array('<3 ','<3 ','<3 ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];}

$exp_nam = explode(' ',$notif[data][$i-1][sender_id][name]);
$nama = $gender.' '.$exp_nam[0];

$tags = explode('_',$notif[data][$i-1][object_id]);
$tagged_name = ' @['.$tags[0].':1] ';

$mess = array(

'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Ada banyak alasan bagi manusia untuk saling membenci, tapi tidak butuh alasan untuk saling menolong..    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Adalah wajar jika kita  bersedih, tapi jangan pernah kesedihan membutakan hatimu hingga kita  berputus asa  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
Akan ada solusi untuk setiap masalah. Hidup terlalu singkat jika hanya untuk mengeluh. Berusaha, percaya diri dan berdoa.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
Allah memberi segalanya secara cuma-cuma, di saat kita tidak layak untuk menerima apa-apa.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Anda bisa sukses sekalipun tak ada orang yang percaya kita  bisa. Tapi kita  tak pernah akan sukses jika tidak percaya pada diri sendiri   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Anda tdk pernah merencanakan masa depan dimasa lalu. (Edmund)   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apa artinya kaki bila kau tak berjalan , Apa guna mata bila tak menatap masa depan , Untuk apa bermimpi, bila kau tak melangkah , Untuk apa kesempatan bila tak ambil celah   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apabila seekor hiu dan singa bertarung siapakah yang akan menang? Tergantung di mana mereka bertarung. So, jangan sekalipun merendahkan orang lain, karena mereka pasti punya tempat di mana Anda akan kalah telak dari mereka.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apapun yang kita  rencanakan, apapun yang kita  ingin lakukan, awalilah dengan doa.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apapun yg kita terima adl akibat dari yg telah kita lakukan. Untuk itu, lakukanlah yg terbaik agar mendapat hasil yg baik pula.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apapun yg telah kita  lakukan, apapun kesalahanmu, kita  akan selalu menemukan kata maaf dalam hati seorang Ibu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Apapun yg terjadi, nikmati hidup ini. Hapus air mata, berikan senyummu. Kadang, senyum terindah datang setelah air mata penuh luka   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Aroma kuteks yang baik biasanya tidak menyengat, hal ini menandakan kandungan kimiawi di dalamnya tidak terlalu banyak.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Asiknya berlari di kenangan masa lalu. Tapi ingat, masa depan terus memanggil-manggil namamu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bahagia bukan milik dia yg hebat dalam segalanya, namun dia yg mampu temukan hal sederhana dlm hidupnya dan tetap bersyukur.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bahagia dan memilih sendiri jalan hidup adalah sesuatu yg harus kita  sadari. Jangan biarkan seorangpun yg menentukannya untukmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bahagia tak datang karena kita  mendapatkan apa yg tak pernah kita  miliki, namun karena kita  menghargai apa yg telah kita  miliki.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bahagialah dengan apa yang kita  miliki. Jangan melepasnya hanya karena rasa takut. kita  mungkin tak akan mendapatkannya kembali  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Banyak hal yang bisa menjatuhkanmu. Tapi satu-satunya hal yang benar-benar dapat menjatuhkanmu adalah sikapmu sendiri.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Banyak orang tua yang publish foto anaknya saat baru lahir.. Dengan kelahiranmu saja, kita  sudah berhasil membuat orang tuamu bangga. Apalagi dengan kesuksesanmu.. Make them proud to have you   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Banyak orang yang menggebu-gebu saat membayangkan mimpinya,  tapi lemah dalam mengejarnya.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Barangsiapa membawa berita tentang orang lain kepadamu, maka dia akan membawa berita tentang dirimu kepada orang lain   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bebaskan dirimu dari belenggu masa lalu. Hiduplah hari ini tuk menciptakan masa depan yg lebih baik. Miliki hati, jadikan berarti.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Beda pendapat sering dipicu oleh beda pendapatan. ??????e  ?? ??___   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Belajar memang melelahkan,namun lebih lelah nanti kelak jikalau saat ini tidak belajar   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berapa Besar ukuran CINTA? Sebesar PERJUANGAN kita untk MEMPERTAHANKAN nya   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berbahagialah mereka yang dapat bertahan di saat menerima keberuntungan dan ketidakberuntungan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berfikir itu cahaya, kelalaian itu kegelapan, kejahilan itu kesesatan & manusia yg paling hina ialah orang yg menganiaya orang bawahannya   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berhenti berusaha tuk jadi yg sempurna. Temukan dia yg tahu semua kelemahanmu tapi tetap ingin menjadi bagian hidupmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berhenti mencari yg sempurna tuk dicintai, karena yg kita  butuh hanya dia yg tahu betapa beruntung dia ketika bersamamu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berhenti sia-siakan hidup menunggu dia yg tak akan pernah jadi milikmu. Hidupmu terlalu berharga tuk itu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berhentilah berprasangka buruk. Karena prasangka itulah yang akan membuatmu menyesal dikemudian hari.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berimajinasilah seperti anak-anak, semangat ala pemuda, dan bijaksana layaknya orang dewasa..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 berlarilah sekencang mungkin,realisasikan lah target yg telah dicanangkan untuk hidup yg lebih baik   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berlarut dalam kesedihan tak akan bisa membuatmu bangkit. Hapus air matamu, segera bergerak maju  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berpikir dengan hati yang jernih, agar semua terlihat lebih jelas. Emosi timbul bukan karena tidak punya hati, tapi karena hati yang ada tidak digunakan dan dijaga dengan semestinya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 BERPIKIR POSITIF dapat menghancurkan semua tembok pemisah antara  tidak bisa  dan  bisa    ',
''.$ucapan.'   '.$nama.' :D ......  ', 
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bersedih dengan orang yg tepat lebih baik daripada berbahagia dengan orang yg salah.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bersyukurlah untuk hari kemarin.. Berdo alah untuk hari esok.. Berjuanglah untuk hari ini..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berusaha keras adalah cara terbaik untuk mengamini tiap doa yang telah kau ucapkan.',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berusaha menjadi yang terbaik itu penting. Tapi yang lebih penting adalah mampu membuat orang-orang di sekeliling kita merasa menjadi diri mereka yang yang terbaik.   ',
''.$ucapan.'   '.$nama.' :D ......  ', 
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Berusahalah terus jangan pantang menyerah seakan akan besok kau akan mendapatkan kebahagian tak terkira   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bkn mereka yg terkuat & terbesar yg akan dapat mempertahankan eksistensinya. Tapi hanya mereka yg mampu beradaptasi terhadap perubahan   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Buka mata kita lebar-lebar sebelum menikah, dan biarkan mata kita setengah terpejam sesudahnya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Bukan harta yang menjadikanmu kaya...Bukan pula usia yang menjadikanmu dewasa.. Kaya adalah ketika kita mensyukuri apa yang kita punya...Dewasa adalah ketika kita menjalani hidup tanpa prasangka...   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cara paling baik untuk tumbuh adalah berusaha dan berdoa, bukan hanya meminta dan berharap pertolongan orang lain.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cermin oh cermin di dinding, tunjukkan padaku siapakah orang paling beruntung di dunia? Cermin menjawab, Tak perlu kutunjukkan, kau telah melihatnya. Ia ada di dalam dirimu, dalam hatimu. Kau sedang beruntung jika kau mempercayainya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta adalah ketika kita  yakin bahwa dirimu telah melupakannya, kita  masih menemukan dirimu peduli padanya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta bukanlah sebuah permainan. Cinta adalah perpaduan dua hati yg saling berjanji, meski pernah tersakiti, cinta tak akan pergi.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta itu antara 2 hati, bukan 3, apalagi 1.. :v   ', 
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta itu mencari kebenaran, bukan mencari-cari kesalahan.   ',
'??????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta itu seperti Biologi n Fisika penuh teori n logika.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta memberimu alasan tuk tersenyum, momen indah tuk ditertawakan, tapi cinta jg memberimu kenangan yg tak pernah bisa dilupakan  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta sejati bukanlah yg berusaha utk mengubahmu, tp yg berhasil menerimamu & tumbuh dewasa bersama dgnmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Cinta tidak hanya tentang  Aku sangat beruntung memilikimu , tapi juga  Kau sangat beruntung memilikiku.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 cintaitu aneh, satu-satunya orang yg bisa membuatmu merasa lebih baik adalah alasan mengapa kita  selalu bersedih.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 COBAAN = LATIHAN. Dan dengan latihan ini kita akan menjadi pribadi yg lebih tangguh, lebih tegar dan lebih bisa bersabar  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam cinta, jika seseorang terus berusaha menyakinkanmu tuk percaya padanya dengan kata, kita  sebaiknya tak percaya padanya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam cinta, tak perlu dia yg berkata bersedia MATI untukmu, karena yg kita  butuh dia yg bersedia HIDUP bersama denganmu   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam cinta, terkadang kita  harus belajar tuk melupakan apa yg kita  rasakan dan mulai menemukan apa yg pantas kita  dapatkan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam dunia ini, tidak ada kesilapan atau ketidak sengajaan. Semua yg mendatangi kita adalah untuk dipelajari.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hal pelajaran sekolah, melupakan lebih mudah daripada mengingat. Namun dalam hal perasaan, melupakan jauh lebih sulit daripada mengingat..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hati ada kekusutan yang tidak akan terurai kecuali dengan menyerahkannya pada-Nya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 dalam hidup adalah belajar bagaimana cara memberikan cinta yg tulus kepada orang lain.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hidup ini, mungkin kita  tak cukup baik bagi semua orang, namun kita  akan selalu jadi yg terbaik dimata sahabatmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hidup keseharian, pikiran past negative dan future negative akan selalu panggil memanggil dan sahut menyahut. Orang yang bertipe past negative hampir pasti selalu berpikiran future negative karena ia akan selalu mengukur masa depan dengan masa lalunya. Dia berpikir bahwa masa depan akan sama suramnya dengan masa lalu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hidup, kita  berhak bahagia. Oleh karena itu, jangan biarkan bahagiamu ditentukan orang lain. Bahagia harus ada dlm dirimu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hidup, kita  harus menyadari, kadang orang yg paling kita  inginkan, adalah orang yg buat hidupmu lebih baik jika tanpanya  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam hidup. jangan paksa apa yg tak bisa kita  lakukan. Lakukan saja apa yg bisa kita  lakukan, biarkan Tuhan melakukan sisanya  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam kerendahan hati ada ketinggian budi. Dalam kemiskinan harta ada kekayaan jiwa. Dalam kesempitan hidup ada kekuasaan ilmu   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam Takut, yg Tampak adlh Hambatan. Dalam YAKIN, yg Tampak adlh KESEMPATAN   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dalam terapi warna memberi warna pastel seperti biru dan hijau pada kamar dapat membuat tidur nyenyak.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dengan memudahkan hidup orang lain, hidup kita akan dimudahkan oleh Tuhan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dia yg mengeluh adalah dia yg tak pernah bisa bersyukur, pdhl tanpa ia sadari, karunia dari Tuhan telah ia nikmati setiap hari.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dia yg tulus mencintaimu takkan berjalan di depanmu, atau tertinggal di belakangmu. Dia akan selalu berjalan di sampingmu  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dibalik setiap kesedihan, terdapat kebahagiaan. Serahkan segala urusan kepada Tuhan. Biarkan waktu dan kehidupan berjalan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dibutuhkan keberanian untuk melakukan kebenaran. Tapi dibutuhkan keberanian sejati untuk mengakui kesalahan sendiri   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Dlm cinta, jgn berdusta hanya karena kita  tak ingin dia terluka. Karena ketika dia temukan kebenaran, dia akan lebih menderita.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Do what you LOVE , and LOVE what you do. And you will get what you want   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Doa tanpa usaha Bohong dan Usaha tanpa doa juga Sombong ..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Doaku hari ini  Tuhan, mudahkan segala urusanku hari ini. Aku berusaha agar yang kulakukan hari ini adalah kebaikan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Doaku hari ini  Tuhan, tetapkan aku dalam keimanan yang kokoh, datangkanlah kebaikan dan jauhkanlah segala keburukan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 lewat kekurangan, kita bisa belajar arti syukur..Ketidaksempurnaan terkadang adalah kesempurnaan tersendiri...   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Fenomena waktu, dia akan berjalan cepat saat kita ingin memperlambatnya, dan akan berjalan lambat saat kita ingin mempercepatnya. Seakan-akan sebulan tak benar-benar sebulan, setahun tak benar-benar setahun.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Fokus pada masalahmu, km tak akan mendapat solusi. Fokus pada Tuhan, Dia akan memberimu solusi.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Friendship doubles your joys, and divides your sorrows   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Genggamlah bumi sblm bumi menggengam kita ,pijaklah bumi sblm bumi memijak kita ,maka perjuangkanlah hidup ini sblm kita  memasuki perut bumi.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hadapi masalah tnpa masalah agar masalah tidak mnjadi risalah kesalahan spanjang perjalanan ini   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal menyedihkan ttng cinta yg berawal dari persahabatan adalah ketika cinta berakhir, dia akan menghancurkan persahabatan yg ada.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal tersulit ketika kita  berpura-pura kuat adalah orang-orang mulai berpikir bahwa kita  pasti akan baik-baik saja meski disakiti.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal yang paling sulit adalah mengalahkan diri sendiri. Tapi itu bisa kita  mulai dengan memaafkan diri sendiri.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal yg harus kita  ingat dalam hidup adalah segala sesuatu tak harus sempurna bagimu tuk menjadi bahagia.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal yg harus kita  ingat dlm cinta, jika kita  ingin memiliki MAWAR yg indah, kita  harus menerima DURI di sekitarnya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hal yg sia-sia tuk menunjukkan betapa besar kita  peduli pd seseorang ketika dia terlalu sibuk mendapatkan perhatian orang lain.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hanya karena kita  tahu dia mencintaimu, tak berarti kita  harus berusaha mencintainya. Jujurlah drpd akhirnya seseorang akan terluka  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hanya karena pernah terluka, tak berati kita  harus takut mencinta. Ada seseorang yg tepat untukmu di luar sana.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hanya karena seseorang pernah melakukan salah di masa lalu, tak berarti dia tak bisa lakukan hal yg baik saat ini.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hanya karena seseorang tersenyum, bukan berarti dia bahagia. Terkadang dia hanya tak ingin terlihat lemah.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hanya seseorang yg bs takut bertindak berani. Tanpa rasa takut itu tidak ada apapun yg bisa disebut berani.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hargai orang lain, siapapun itu, dan jangan pernah menaruh dendam kepada siapapun. Isi setiap harimu dengan kebaikan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hargailah mereka yg telah berkata jujur kepadamu, karena bagi beberapa orang, mereka lebih suka mengatakan apa yg ingin kita  dengar   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hari ini gagal? Besok coba lagi dengan cara berbeda.. Besok gagal? Lusa coba lagi dengan cara berbeda.. Lusa gagal lagi? Berarti sudah bertambah ilmu baru    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Harus berani jujur terhadap diri sendiri agar tidak terjebak dalam realita yang semu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup adalah pemberian Tuhan. Bersyukur dengan bekerja/menuntut ilmu adalah wujud kasih kita kepada Sang Pemberi Hidup.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup bukanlah tentang  Aku bisa saja , namun tentang  aku mencoba . Jangan pikirkan tentang kegagalan, itu adalah pelajaran.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup ini penuh pilihan, kita  selalu bisa memilih tuk tetap bersama dia yg buatmu menangis, atau temukan dia yg buatmu tersenyum   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup ini penuh pilihan. Semakin baik keputusan yang kita  pilih semakin baik juga kita  dalam mengendalikan kehidupanmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup ini penuh warna,kitalah yang harus berusaha mengisi tuk hidup penuh warna cerah   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup ini sederhana. Jika kita  ingin hidup bahagia, mulailah meninggalkan segala sesuatu yang membuatmu tak bahagia.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup tak selalu sesuai keinginanmu. Selalu ada masalah, namun masalah membawa pengalaman, dan pengalaman membawa kebijaksanaan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup tak slalu ttg dirimu saja. Tak peduli kita  yg terbaik atau yg terburuk, tak semua orang peduli denganmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup tanpa mempunyai TUJUAN sama seperti   Layang-layang putus  Miliki tujuan dan PERCAYALAH kita  dapat mencapainya   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup terlalu singkat tuk terus mengenang cintamu di masa lalu, ketika kita  bisa menciptakan cerita baru dengan yg mencintaimu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidup tidak hanya dari apa yang kita tinggalkan, tapi kemana kita akan menuju...    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hidupmu adalah milikmu, kita  sendiri yg menentukan baik buruknya, dan kita lah yg memimpin dirimu sendiri, bukan orang lain.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Hujan selalu mampu menghipnotis akan kenangan masa lalu. Saat kita masih kecil dulu, hujan selalu menggoda kita untuk bermain di dalamnya. Namun seiring perjalanan usia, hujan hanya akan menggoda untuk tidur. Dalam esensinya, hujan tidak diciptakan untuk membuat manusia menjadi malas.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Ikhlaslah dalam pengorbananmu akan beberapa hal yang kau miliki, maka Tuhan akan mempersiapkan orang-orang yang suatu saat akan ikhlas dalam berkorban untukmu...   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Ilmu itu di dapat dari lidah yg gemar bertanya dan akal yg suka berpikir.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jadilah berkat bagi banyak orang. Berbagi itu indah teman   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jadilah seperti semut, dimanapun ?? makanan  disimpan, mereka seperti tak pernah kehabisan akal untuk mengambilnya..    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan awali hari dengan penyesalan hari kemarin, karena akan menggangu hebatnya hari ini, dan akan merusak indahnya hari esok.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan bandingkan orang yg mencintaimu saat ini dgn masa lalumu. Hargai dia yg kini berusaha buatmu bahagia.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan berubah hanya karena ingin dicintai seseorang. Jadilah dirimu sendiri dan seseorang akan mencintai kita  apa adanya..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan berusaha jadi orang lain. kita  terlahir karena sebuah alasan. Maksimalkan diri tuk capai kebahagiaanmu sendiri.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan biarkan bayangan masa lalu merusak sinar matahari untuk hari esok, Hiduplah untuk hari ini.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan biarkan dirimu terpaku dengan hubungan masa lalu, yg berakhir telah berakhir. Lebih baik temukan seseorang yg baru. MOVE ON   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan biarkan orang lain menghalangimu tuk mengejar impianmu. Tetap berjuang, dan percayalah, semua akan indah pada waktunya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan bilang hidup ini tidak adil. Hidup ini sangat adil. Karena segala kesulitan akan diganti dengan yang kemudahan. Terkadang hati kita yang tidak adil dalam melihat sesuatu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan hiraukan mereka yg berbicara buruk di belakangmu, mereka yg menghabiskan waktunya hanya tuk memikirkan dirimu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan hiraukan mereka yg berusaha jatuhkanmu. Karena mereka akan kalah dengan sendirinya ketika melihatmu masih tegak berdiri.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan jadikan kelamnya masa lalu sebagai alasan untuk tidak berbuat yang terbaik hari ini.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan lihat siapa yg berbicara, tapi dengarkan apa yg mereka bicarakan.    ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan membalas mereka yg membencimu. Tersenyum & berbahagialah di depan mereka, tak ada yg lebih menyakiti mereka daripada itu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan membenci orang yang pernah menyakitimu. Sebenarnya mereka tidak benar-benar menyakitimu. Mereka hanya dititipi peran antagonis agar kita  lebih kuat.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan memberi harapan pada seseorang jika tak cinta. Berpikir mempunyai kesempatan yg sebenarnya tak nyata, menyakitkan   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan meminta pembenaran dari orang lain jika sebenarnya kita  tahu jika pendapatmu adalah sebuah kesalahan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan mengeluh tentang harimu. Setiap harimu mungkin tak baik, namun percayalah ada sesuatu yg baik di setiap harimu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan mengeluhkan hal-hal buruk yg datang dalam hidupmu. Tuhan tak pernah memberikannya, kita lah yg membiarkannya datang.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menghakimi orang lain, jika kita  tak tahu apa yg telah dia lalui dan perjuangkan dalam hidupnya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan mengulangi kesalahan yg sama. Di setiap kesalahan ada pelajaran yang berharga. Gunakan itu dalam kesempatan berikutnya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menunda sebuah pekerjaan, lebih baik menyesali apa yg kita  kerjakan, daripada menyesali apa yg tak pernah kita  kerjakan  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menyalahkan keberuntungan orang lain atas ketidakberuntunganmu. Tapi jadikanlah itu sebagai inspirasi bahwa keberuntungan tidak akan mendatangimu, tapi kita  yang harus menjemputnya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menyerah atas sesuatu yg sangat kita  inginkan. Memang sulit tuk menunggu, tapi akan lebih sulit jika akhirnya kita  menyesal  ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menyerah ketika yang diinginkan belum bisa didapatkan. Karena sesuatu yg berharga biasanya tidak mudah untuk diraih.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menyombongkan sebuah tanggung jawab. Sebelum kita  harus mempertanggung jawabkan kesombongan itu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan menyukai orang lain karena apa yang ia punya..Dan jangan meninggalkan orang lain karena apa yang tidak ia punya..Karena suatu saat mungkin orang lain juga akan meninggalkanmu karena apa yang tidak kita  punya..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan Merangkak dalam Keraguan, Berlarilah dengan KEYAKINAN   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan paksakan diri tuk cari yg terbaik, biarkan cinta yg menemukanmu. Percaya, yg terbaik pasti datang pd mereka yg menunggu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan permainkan perasaan seseorang. Jika kita  memanfaatkannya, cepat atau lambat dia pasti akan meninggalkanmu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah bosan untuk menjadi diri sendiri karena mungkin banyak orang di luar sana yang ingin menjadi dirimu...   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah lelah melakukan hal kecil tuk orang lain. Terkadang, hal kecil itu mampu berikan bahagia di hati mereka.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah membandingkan orang disekitarmu, terlebih orang yg kita  cintai. Tak ada manusia yg sempurna. Cintai apa adanya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 jangan pernah meninggalkan orang yang kita  sayangi hanya demi orang yang kita  sukai.. karena suatu saat orang yang kita  sukai bisa saja meninggalkanmu demi orang yang dia sayangi..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah menyalahkan masa lalu. Yang salah adalah jika saat ini kita  masih meratapinya.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah menyerah jika kita  masih ingin mencoba. Jangan biarkan penyesalan datang karena kita  selangkah lagi tuk menang.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah menyerah, segala sesuatu akan selalu berakhir indah. Jika tidak indah, artinya kita  belum mencapai titik akhir.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah menyesali apapun yang kita  lakukan dengan keikhlasan hati, sesuatu yang datang dari hati akan selalu berarti.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah meremehkan orang lain, terkadang orang yg kita  butuhkan adalah mereka yg pernah kita  remehkan. Tetap rendah hati.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan pernah terpuruk karena suatu masalah, bersabar dan berdoa. Percayalah, Tak ada masalah yang terlalu besar bagi Tuhan.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan puas hanya dengan sebuah statement akhir. Telusuri proses dibalik itu dan engkau akan dua kali lebih mengerti arti dari statement itu.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan sekali-kali kita meremehkan sesuatu perbuatan baik walaupun hanya sekadar senyuman   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan sekali-kali merasa dirimu bukan apa-apa. Tanpa dirimu, dunia akan mengalami sedikit perubahan.  Tidak percaya? Silakan ditanyakan pada orangtuamu..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan sekalipun menyalahkan keadaan, karena rezeki selalu ada.. Masalahnya apakah kita ingin mengambilnya atau melewatkannya..   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan sesali sesuatu yg telah berakhir, meskipun itu baik. Tanpa akhir tak akan pernah ada awal baru yg mungkin lebih baik.   ',
'?????? Oo....................
'.$emojitor.' : 

?????? '.$tagged_name.'
 Jangan takut akan luka, karena luka bisa sembuh. Jangan sengaja melukai, karena luka bisa berbekas. Tapi jangan takut akan bekas lukita , karena bekas luka itu bisa ditutupi dengan keyakinanmu akan kesembuhanmu.   ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Ada temen berkunjung gak ada cemilan-nya  
',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Yang laen pada kmana ya , koq sepi hehee
?? ?? ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Silaturahmi sesama teman fb harus tetap di jaga, 
kalo ada ?? temen ?? komen kita jempolin dan komen 
?? ??setuju gak :D, ..... ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
AyoOo .. semangat !?? ??:Jangan menyerah 
ketika yang diinginkan belum bisa didapatkan. 
Karena sesuatu yg berharga biasanya 
tidak mudah untuk diraih .. ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
aku ikut aja deech .. ? ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Ku Hadir adA ?? makanan  gak hehee ..  ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
maap sebenernye aku bot loh soalna 
boss aku lagi off line nieh .... ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
maap ya sobatku jika komen gk nyambung, 
maklum cuma robot komen .. ?, 
jika ada yg penting silahkan inbox saya
.. ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
ada promo Telkomsel gratis bicara kapan aja 
& dimana aja caranya tekan no tujuan 
lalu matiin hp, baru bicaralah sesuka anda, 
pasti gratis! ,..
',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
" IM3 Sekarang bisa TELPON GRATIS ke SEMUA OPERATOR looh .. 
Caranya: Ketik NO TUJUAN tambahkan 388 Trus 
dibelakangnya Lampirkan SURAT KETERANGAN MISKIN dari KELURAHAN , ..:D 
hahahaa ,, ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
bakar rumah aja yuuk biar tambah rame ..
? ?? ?? ??  .. ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
padahal ak tuh gak pelit-pelit amat buat jempol 
& komen di status ?? temen ?? 
tapi kalo aku bikin statuz mereka jarang komen ya
?? ?? hahahaa .. ', 

'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
fb itu kan buat komunikasi, 
kalo ada yang komen wajib kita jempolin ..
?? ??hehee .............
kalo diem-dieman ntar di kira kita musuhan 
',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Mo telepon gratis dari operator Fren ?? � 
caranya gini bilang aja FREN pinjem telpon donk! 
..?? ??xixii ,, ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
ehmm.. koq yang laen pada diem, !! 
main jempol-jempolan aja yuuk ? .. ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Yang laen pada kmana ya , ?? ...
koq sepi hehee?? ??:D,, ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
hadir mu di sini udah di tunggu sma yg laen twuh ... 
biar tambah Siiip Ayoo ikutan komen  ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
fb kalo cuma like komen doang mendingan baca koran aja, 
bener ga tuh , yuk komenan biar gak sepi
??????',

'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
karena kamu baik hati, 
aku doain cepet punya rumah mewah, 
kapal pesiar, dan yang terakhir ...
saya doain tetep jadi orang baik 
hehee ... mau yaaaa ? ? ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
kadang hp jadul ku loading nya lemot banget ....
mau bales komen aja susah?? ?? . . .
padahal hp ku udah pake antena TV hehee ',		 
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
Suka jempol-jempolan .. ? mampir ke statuz aku ea ..  ',
'?????? Oo....................
'.$emojitor.' :

?????? '.$tagged_name.'
hp ku loading y lagi lemot bener  ......
hehee  ',
);              

$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 01) $_sambutan = "Met dini hari .";
else if ($_time > 24) $_sambutan = "Good merem . ";
else $_sambutan = "Selamat Pagi  ";

$gentime = microtime();
$gentime = explode(' ',$gentime);
$gentime = $gentime[0];
$pg_end = $gentime;
$totaltime = ($pg_end - $pg_start);
$showtime = number_format($totaltime, 1, '.', '');

$hari=gmdate("D", time()+60*60*7);
if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Sunday"; }
if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Monday"; }
if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Tuesday"; }
if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Wednesday"; }
if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Thursday"; }
if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Friday"; }
if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Saturday"; }
$jame=" ".gmdate("g:i:s a", time()+60*60*7);
$tgl=" ".gmdate("j - m - Y", time()+60*60*7);

$habiscomment1=array(
'

<3 Happy '.$hari.' :*
..............................................Oo ?????? 
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salam Robot :|] ...
..............................................Oo ?????? 
https://m.facebook.com/profile.php
VIP Account � Gentho-Bot   
',
'

<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
https://m.facebook.com/profile.php
Official Profile� Gentho-Bot   
',
'

<3 Salam Persahabatan  :* ...
..............................................Oo ?????? 
https://m.facebook.com/profile.php
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salam Silaturahmi ...
'.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile� Gentho-Bot   
',
'

<3 Semoga Sukses ! ?? amin .
..............................................Oo ?????? 
'.$hari.' � '.$tgl.' � '.$jame.'
VIP Account � Gentho-Bot   
',
'

<3 Salkombot :|] ...
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
PoWered.� Gentho-Bot� Gentho-Bot   
',
'

<3 Salkomsel ? ...
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile Gentho-Bot   
',

'

<3 Salam Jempol ??????
<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
VIP Account � Gentho-Bot   
',
'

<3 Salam boters :|] ...
..............................................Oo ?????? 
PoWered.� Gentho-Bot   
',
'

<3 '.$hari.' � '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
https://m.facebook.com/profile.php
Official Profile� Gentho-Bot   
',
'

<3 Salam kompak (Y) ..
<3 Have a nice '.$hari.' :*
<3 '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
VIP Account � Gentho-Bot   
',
'

<3 Sukses selalu untukmu ..
..............................................Oo ?????? 
<3 '.$tgl.' � '.$jame.' �
PoWered.� Gentho-Bot   
',
'

<3 Happy '.$hari.' :*
<3 '.$tgl.' � '.$jame.' �
..............................................Oo ?????? 
Official Profile� Gentho-Bot   
',
'

<3 Add / Ikuti / Follow Me ??????
..............................................Oo ?????? 
https://m.facebook.com/profile.php
VIP Account � Gentho-Bot   
',
'

<3 Salam santun :) . .
..............................................Oo ?????? 
https://m.facebook.com/profile.php
PoWered.� Gentho-Bot   
',
);
$habiscomment2=$habiscomment1[rand(0,count($habiscomment1)-1)];


$message1 = ' '
.$mess[rand(0,count($mess)-1)];

$message =($message1.$habiscomment2);       

		   
		   
           auto('https://graph.facebook.com/'.$notif[data][$i-1][object_id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'&method=post'); echo $notif[data][$i-1][object_id].' => '.$message.'<hr/>';
           }
       }
   }

function auto($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }

?>