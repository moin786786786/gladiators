﻿<?php
$text = array(

"Apa kabar 
",
"Hello_ 
",
"Hai 
",
"Hadir_ 
",
"Gimana kabarnya ..
",
"Ngopi dulu ...
",
"Coffee break_ 
",
"Like this ....... 
",
"Like Like an yuk .... 
",
"Jempol hadir .......
",
"Permisi numpang lewat :) 
",
" :D Misi ..misi ...misi ... 
",
"Apa :D kabar .. 
",
"Salkomsel .. (Y) 
",
"(Y) Salam kompak .. 
",
"Hadiiiiiir .. :D 
",
":D Salam PP .. 
",
"Assalamualaikum ... :) 
",
"[H][A][D][I][R] ^_^ .. 
",
"[L][I][K][E] (y) .. 
",
"pokoknya setuju aja :D .. 
",
"hadir :D .. 
",
"sejutu,,,,eits setuju.. :D .. 
",
"Numpang lewat, :D .. 
",
"Sambil absen ya, :D .. 
",
"mampir dulu .. 
",
":D Absen komen ..  
",
"Titip (Y) jempol .. 
",
"Hadiir biar tambah rame :D .. 
",
"Mampir dulu .. :D  
",
"Titip jempol :D .. 
",
"Apa kabar .. :D 
",
":D Semoga sehat selalu .. 
",
"Semoga kebaikan selalu menyertai kita .. :)  
",
"Salam Santun .. 
",
"Salam Silaturahmi .. 
",
"Semoga kita senantiasa diberi kesehatan amin .. 
",
"Halloo :D 
",

);

?>
